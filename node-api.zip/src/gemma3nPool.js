// Isolates Gemma 3n inference (gemma3nWorker.js) in a forked child
// process, so an OOM kill — confirmed to happen on this machine, twice
// while idle and once on a real multi-page document — only takes down
// that one request instead of the whole server. Same rationale as
// app/ocr_pool.py's ProcessPoolExecutor: a crash-prone heavy operation
// gets its own process, and the pool respawns a fresh one after a crash
// rather than requiring a manual server restart.

import { fork } from "child_process";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const WORKER_PATH = path.join(__dirname, "gemma3nWorker.js");

let child = null;
const pending = new Map();
let nextId = 0;

function spawnChild() {
  const proc = fork(WORKER_PATH);

  proc.on("message", (msg) => {
    const entry = pending.get(msg.id);
    if (!entry) return;
    pending.delete(msg.id);
    if (msg.ok) entry.resolve(msg.result);
    else entry.reject(new Error(msg.error));
  });

  proc.on("exit", (code, signal) => {
    // Died unexpectedly — most likely an OOM kill (SIGKILL). Reject
    // whatever was in flight with a clear reason instead of letting the
    // main server process go down with it, and drop the reference so the
    // next call spawns a fresh worker rather than reusing a dead one.
    const reason = signal
      ? `Gemma worker was killed (signal ${signal}, most likely out-of-memory on this machine). This request was not completed, but the rest of the API is unaffected.`
      : `Gemma worker exited unexpectedly (code ${code}).`;
    for (const { reject } of pending.values()) reject(new Error(reason));
    pending.clear();
    if (child === proc) child = null;
  });

  return proc;
}

function getChild() {
  if (!child) child = spawnChild();
  return child;
}

function callWorker(type, payload) {
  return new Promise((resolve, reject) => {
    const id = nextId++;
    pending.set(id, { resolve, reject });
    getChild().send({ id, type, ...payload });
  });
}

export function extractFieldsWithGemmaSafe(text) {
  return callWorker("extractFields", { text });
}

export function answerQuestionsWithGemmaSafe(text, questions) {
  return callWorker("answerQuestions", { text, questions });
}
