// US legal filings overwhelmingly share this caption structure:
//   <party name(s)>
//   Plaintiff,
//   v.
//   <party name(s)>
//   Defendant(s).
// This is a structural/layout pattern, not natural prose — exactly what a
// general QA/generative model handles poorly. Verified across four
// separate real-document test rounds this session with four different AI
// approaches (extractive QA, extractive QA asked fixed field questions, a
// small generative LLM, and a larger generative LLM (Phi-3-mini, ~3.8B)):
// every one either got the plaintiff wrong/missing, fabricated text, or
// was too slow to be usable (Phi-3-mini took ~7 minutes per document on
// CPU) — while this deterministic parser was correct and near-instant on
// every real filing tested. A parser keyed off these caption markers is
// the right tool for this specific, extremely common structural question.
//
// Plaintiff/Defendant is the civil-suit convention (Federal Rule of Civil
// Procedure 10(a) and equivalent state rules), but it's not the only role
// pair US courts use — family law, administrative, and probate matters
// commonly caption as Petitioner/Respondent, and appellate matters as
// Appellant/Appellee. Same structural position (name, role label, "v.",
// name, role label), different vocabulary, so each pair gets tried in
// turn and the output key uses whichever term the document actually used
// (not forced to "Plaintiff"/"Defendant") — a family-law petition
// shouldn't come back mislabeled. NOTE: only the Plaintiff/Defendant path
// has been verified against real filings this session (4 different
// Florida counties); the Petitioner/Respondent and Appellant/Appellee
// paths are added from documented US court captioning convention, not yet
// tested against a real sample of that document type — flagged here
// rather than presented as equally proven.
const ROLE_PAIRS = [
  {
    firstRe: /^plaintiffs?\.?,?\b/i,
    secondRe: /^defendants?\(?s?\)?\.?,?\b/i,
    firstKey: "Plaintiff",
    secondKey: "Defendant",
  },
  {
    firstRe: /^petitioners?\.?,?\b/i,
    secondRe: /^respondents?\(?s?\)?\.?,?\b/i,
    firstKey: "Petitioner",
    secondKey: "Respondent",
  },
  {
    firstRe: /^appellants?\.?,?\b/i,
    secondRe: /^appellees?\.?,?\b/i,
    firstKey: "Appellant",
    secondKey: "Appellee",
  },
];

const VS_LABEL_RE = /^v\.?s?\.?,?$/i;

// case\s*no\.?.* / case\s*number.* / docket\s*no.* / civil\s*action\s*no.* /
// index\s*no.* (not just a bare "...:?" label) so a caption line like
// "CASE No. 2020 CA 001231 NC" — the case number typed inline with no
// colon, verified on a real filing — doesn't get swept into the plaintiff
// name by the backward scan below (it produced "CASE No. 2020 CA 001231
// NC U.S. BANK TRUST NATIONAL ASSOCIATION..." before this fix). The
// actual case number itself is captured separately by
// caseInfoExtraction.js, so this parser only needs to recognize and skip
// the line, not parse its value. "Docket No."/"Civil Action No." (federal
// courts) and "Index No." (New York) are documented alternate labels for
// the same field, added alongside the verified "Case No." — not yet
// tested against a real federal or NY filing.
const NOISE_LABEL_RE =
  /^(general\s+jurisdiction|jurisdiction\s+division|division:?|case\s*no\.?\b.*|case\s*number\b.*|docket\s*no\.?\b.*|civil\s*action\s*no\.?\b.*|index\s*no\.?\b.*|div:?\s*\w*)$/i;

// OCR sometimes misreads the "v." divider itself as unrecognizable garbage
// — verified on a real scanned filing where it came out as "\2" (not "v."
// or "vs." in any recognizable form), which VS_LABEL_RE can't match, so it
// fell through into the defendant name as "\2 Jeannie Quinteros, et al".
// A line with no letters at all and only a handful of characters is never
// real party-name content, whatever OCR turned "v." into, so it's treated
// as noise and skipped rather than trying to enumerate every possible OCR
// misread of a single character.
const NOISE_TOKEN_RE = /^[^A-Za-z]{1,4}$/;

const COURT_HEADER_RE =
  /^(IN THE .*(COURT|CIRCUIT).*|.*JUDICIAL (CIRCUIT|DISTRICT).*|IN AND FOR .*|.*COUNTY,?\s*[A-Z]{2,}\.?$)/i;

// Some PDFs' text extraction puts each word of a fully-justified party
// name on its own line (e.g. "TOWN" / "VILLAS" / "AT" / "MOON" / "LAKE" /
// "HOMEOWNERS ASSOCIATION, INC.," as six separate lines for one plaintiff
// name) — verified against a real filing where a cap of 5 silently dropped
// the first word ("TOWN"). Raised with headroom for longer corporate/HOA
// names in this same layout.
const MAX_PARTY_LINES = 12;

function cleanParty(lines) {
  return lines.join(" ").replace(/\s+/g, " ").trim().replace(/^[ ,;]+|[ ,;]+$/g, "");
}

function findLabel(lines, pattern, start = 0) {
  for (let i = start; i < lines.length; i++) {
    if (pattern.test(lines[i])) return i;
  }
  return -1;
}

function extractForRolePair(lines, rolePair) {
  const { firstRe, secondRe, firstKey, secondKey } = rolePair;

  const pIdx = findLabel(lines, firstRe);
  if (pIdx === -1) return {};

  const vIdx = findLabel(lines, VS_LABEL_RE, pIdx + 1);
  const dIdx = findLabel(lines, secondRe, vIdx !== -1 ? vIdx + 1 : pIdx + 1);

  // First party's name: scan backward from its role marker, collecting
  // real content lines and skipping administrative labels, stopping at
  // the jurisdiction header or a blank line once something's been found.
  const firstLines = [];
  let i = pIdx - 1;
  while (i >= 0 && firstLines.length < MAX_PARTY_LINES) {
    const line = lines[i];
    if (!line) {
      if (firstLines.length) break;
      i -= 1;
      continue;
    }
    if (COURT_HEADER_RE.test(line)) break;
    if (NOISE_LABEL_RE.test(line) || firstRe.test(line) || NOISE_TOKEN_RE.test(line)) {
      i -= 1;
      continue;
    }
    firstLines.unshift(line);
    i -= 1;
  }
  const first = cleanParty(firstLines);

  // Second party's name(s): everything between the "v."/"vs." marker (or
  // the first party's marker, if no "v." was found) and its role marker.
  let second = "";
  if (dIdx !== -1) {
    const start = vIdx !== -1 ? vIdx + 1 : pIdx + 1;
    const secondLines = [];
    for (let j = start; j < dIdx; j++) {
      if (lines[j] && !NOISE_LABEL_RE.test(lines[j]) && !VS_LABEL_RE.test(lines[j]) && !NOISE_TOKEN_RE.test(lines[j])) {
        secondLines.push(lines[j]);
      }
    }
    second = cleanParty(secondLines);
  }

  const result = {};
  if (first) result[firstKey] = first;
  if (second) result[secondKey] = second;
  return result;
}

export function extractParties(text) {
  const lines = text.split("\n").map((ln) => ln.trim());

  for (const rolePair of ROLE_PAIRS) {
    const result = extractForRolePair(lines, rolePair);
    if (Object.keys(result).length) return result;
  }
  return {};
}
