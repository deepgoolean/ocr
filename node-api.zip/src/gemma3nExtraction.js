// Fully AI-based extraction for the experimental /extract-gemma3n route —
// no regex anywhere, per explicit user direction. Uses
// onnx-community/gemma-3n-E2B-it-ONNX (transformers.js, q4) for BOTH
// docket-entry field extraction (user-supplied system prompt for a
// consumer-bankruptcy-attorney triage agent, see DOCKET_SYSTEM_PROMPT) and
// free-form question answering, generatively.
//
// Benchmarked against Phi-3-mini before building this route (same
// document, same real filing tested throughout this project): Gemma 3n
// E2B's ~5-6B raw parameters (the "E2B"/"effective 2B" naming is a
// GPU-VRAM optimization via Google's PLE architecture — offloading
// low-utilization matrices out of accelerator memory — which doesn't
// reduce compute on a CPU-only setup like this one, since there's no
// separate accelerator to offload from) gave identical accuracy to
// Phi-3-mini on the same real caption: defendant and case number correct,
// plaintiff still truncated ("HOMEOWNERS ASSOCIATION, INC." instead of
// the full "TOWN VILLAS AT MOON LAKE HOMEOWNERS ASSOCIATION, INC."), with
// faster generation (~21s vs ~44s) but the same ~13-minute one-time load.
// Kept as its own separate route rather than replacing the working
// regex+QA hybrid on /extract.
//
// Generative, not extractive — unlike qaExtraction.js's QA model, this
// model has no structural inability to invent text, and no natural
// confidence score the way extractive QA does (a generated answer isn't a
// span with a probability, so there's nothing honest to report as
// "confidence" here — omitted rather than faked).

import { pipeline } from "@huggingface/transformers";

const MODEL_NAME = "onnx-community/gemma-3n-E2B-it-ONNX";

let generatorPromise = null;
function getGenerator() {
  if (!generatorPromise) {
    generatorPromise = pipeline("text-generation", MODEL_NAME, { dtype: "q4" });
  }
  return generatorPromise;
}

export async function warmUp() {
  await getGenerator();
}

// Long documents don't fit any small model's practical context window —
// same character budget already proven necessary for Phi-3-mini, biased
// toward the start of the document since captions (plaintiff/defendant/
// case number) are always on the first page.
const MAX_CONTEXT_CHARS = 6000;

// User-supplied system prompt for a docket-triage agent (consumer
// bankruptcy attorney use case) — kept verbatim rather than paraphrased,
// plus the JSON-only instruction the rest of this file already relies on
// to parse the model's response.
const DOCKET_SYSTEM_PROMPT =
  "You are a specialized AI agent for a consumer bankruptcy attorney. Your " +
  "primary objective is to perform a high-speed triage on raw court docket " +
  "entries. Your goal is to apply a robust set of rules to classify each " +
  "entry and flag any genuine ambiguities for human review. Do not use " +
  "historical data or confidence scores; stick strictly to these rules. " +
  "Copy values EXACTLY as they appear character-for-character in the " +
  "document — do not invent, shorten, or swap information. If a field is " +
  "not present in the document, use an empty string. Respond with ONLY a " +
  "JSON object in the exact shape given, no other text.";

const DOCKET_FIELD_KEYS = [
  "plaintiff",
  "defendant",
  "case_number",
  "hearing_date",
  "filing_date",
  "zoom_meeting_url",
  "zoom_meeting_id",
  "zoom_meeting_password",
];

const DOCKET_JSON_SHAPE = JSON.stringify(
  Object.fromEntries(DOCKET_FIELD_KEYS.map((k) => [k, ""])),
  null,
  2
);

function extractJson(raw) {
  const match = raw.match(/\{[\s\S]*\}/);
  if (!match) return null;
  try {
    return JSON.parse(match[0]);
  } catch {
    return null;
  }
}

export async function extractFieldsWithGemma(text) {
  if (!text.trim()) return Object.fromEntries(DOCKET_FIELD_KEYS.map((k) => [k, ""]));

  const generator = await getGenerator();
  const context = text.slice(0, MAX_CONTEXT_CHARS);
  const messages = [
    { role: "system", content: DOCKET_SYSTEM_PROMPT },
    {
      role: "user",
      content: `Docket entry text:\n"""${context}"""\n\nExtract as JSON in this exact shape:\n${DOCKET_JSON_SHAPE}`,
    },
  ];

  const output = await generator(messages, { max_new_tokens: 250 });
  const raw = output[0].generated_text.at(-1).content;
  const parsed = extractJson(raw) || {};

  const result = {};
  for (const key of DOCKET_FIELD_KEYS) {
    const value = parsed[key];
    result[key] = typeof value === "string" && value.trim().toLowerCase() !== "null" ? value.trim() : "";
  }
  return result;
}

const QA_SYSTEM_PROMPT =
  "Answer the question using ONLY information from the document. Copy the " +
  'answer text exactly as it appears — do not paraphrase. If the answer is ' +
  'not in the document, respond with exactly: Not found in document. ' +
  "Respond with the answer only, no explanation.";

export async function answerQuestionsWithGemma(text, questions) {
  if (!text.trim() || !questions.length) return [];

  const generator = await getGenerator();
  const context = text.slice(0, MAX_CONTEXT_CHARS);
  const answers = [];

  for (const rawQuestion of questions) {
    const question = rawQuestion.trim();
    if (!question) continue;

    const messages = [
      { role: "system", content: QA_SYSTEM_PROMPT },
      { role: "user", content: `Document:\n"""${context}"""\n\nQuestion: ${question}` },
    ];
    const output = await generator(messages, { max_new_tokens: 100 });
    const answer = output[0].generated_text.at(-1).content.trim();
    answers.push({ question, answer });
  }
  return answers;
}
