// Port of app/key_value_extraction.py: matches "Label: Value" on a single
// line — common in forms, cover sheets, and legal filings (e.g. "Street
// Address: 503 SW 16th Street", "Case No.: 12345"). Deliberately
// conservative: short, capitalized-looking label, non-empty value, single
// line only. Regex, not AI — the label text is wanted verbatim as it
// appears in the document, not bucketed into a generic category.

const LABEL_VALUE_RE = /^[ \t]*([A-Z][A-Za-z0-9 /#.,'-]{1,48}?)[ \t]*:[ \t]+(\S.{0,200}?)[ \t]*$/gm;

const MAX_PERIODS_IN_LABEL = 1;

export function extractKeyValues(text) {
  const seen = new Set();
  const pairs = [];
  LABEL_VALUE_RE.lastIndex = 0;
  let match;
  while ((match = LABEL_VALUE_RE.exec(text)) !== null) {
    const label = match[1].trim();
    const value = match[2].trim();
    if (!label || !value) continue;
    if ((label.match(/\./g) || []).length > MAX_PERIODS_IN_LABEL) continue;
    const dedupKey = `${label} ${value}`;
    if (seen.has(dedupKey)) continue;
    seen.add(dedupKey);
    pairs.push({ key: label, value });
  }
  return pairs;
}
