// Split-to-temp-file + OCR pipeline, shared by both routes in server.js:
// /extract-text-simple (text only) and /extract (text + AI analysis).

import fs from "fs/promises";
import os from "os";
import path from "path";
import { splitPdfToTempImages } from "./pdfPaging.js";
import { runOcr } from "./ocrPool.js";

async function resolvePage(item) {
  const splitSeconds = Number(item.splitSeconds.toFixed(3));

  if (item.kind === "digital") {
    return {
      page_number: item.pageNumber,
      method: "digital",
      text: item.text,
      confidence: null,
      split_seconds: splitSeconds,
      ocr_seconds: 0,
      total_seconds: splitSeconds,
    };
  }

  const imageBytes = await fs.readFile(item.imagePath);
  const { text, confidence, ocrSeconds } = await runOcr(imageBytes);
  const roundedOcrSeconds = Number(ocrSeconds.toFixed(3));
  return {
    page_number: item.pageNumber,
    method: "ocr",
    text,
    confidence: Number(confidence.toFixed(4)),
    split_seconds: splitSeconds,
    ocr_seconds: roundedOcrSeconds,
    total_seconds: Number((splitSeconds + roundedOcrSeconds).toFixed(3)),
  };
}

export async function extractPages(filename, content) {
  const start = process.hrtime.bigint();
  const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "pdf_ocr_split_"));

  let pages;
  let splitPhaseSeconds;
  let ocrPhaseSeconds;
  try {
    const splitStart = process.hrtime.bigint();
    const tempPages = await splitPdfToTempImages(content, tempDir);
    splitPhaseSeconds = Number(process.hrtime.bigint() - splitStart) / 1e9;

    const ocrStart = process.hrtime.bigint();
    pages = await Promise.all(tempPages.map(resolvePage));
    ocrPhaseSeconds = Number(process.hrtime.bigint() - ocrStart) / 1e9;
  } finally {
    await fs.rm(tempDir, { recursive: true, force: true });
  }

  const orderedPages = [...pages].sort((a, b) => a.page_number - b.page_number);
  const fullText = orderedPages.map((p) => p.text).join("\n\n");
  const elapsed = Number(process.hrtime.bigint() - start) / 1e9;

  return {
    filename,
    num_pages: orderedPages.length,
    pages: orderedPages,
    full_text: fullText,
    split_phase_seconds: Number(splitPhaseSeconds.toFixed(3)),
    ocr_phase_seconds: Number(ocrPhaseSeconds.toFixed(3)),
    processing_time_seconds: Number(elapsed.toFixed(3)),
  };
}
