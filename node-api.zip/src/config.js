export const config = {
  port: parseInt(process.env.PORT || "3000", 10),
  dpi: parseInt(process.env.OCR_DPI || "200", 10),
  digitalTextMinChars: parseInt(process.env.DIGITAL_TEXT_MIN_CHARS || "20", 10),
  maxUploadMb: parseInt(process.env.MAX_UPLOAD_MB || "50", 10),
  ocrLanguage: process.env.OCR_LANGUAGE || "eng",
  // Tesseract.js workers each run in their own worker thread, so a handful
  // is cheap compared to the Python EasyOCR/PaddleOCR pools (no multi-GB
  // model load per worker) — default to CPU count, same rationale as
  // OCR_WORKERS on the Python side (bound parallelism to real cores).
  ocrWorkers: parseInt(process.env.OCR_WORKERS || "2", 10),
  // A page's embedded image is treated as "the whole page" (and OCR'd)
  // once it covers this fraction of the page area — mirrors
  // app/pdf_paging.py's _FULL_PAGE_IMAGE_AREA_RATIO so a short text
  // watermark stamped over a scanned page doesn't get misclassified as
  // digital text.
  fullPageImageAreaRatio: 0.85,
};
