// Pool of Tesseract.js workers behind a Scheduler, so OCR jobs for
// different pages run concurrently instead of queueing behind one worker —
// same rationale as app/ocr_pool.py's ProcessPoolExecutor, just with
// worker threads instead of OS processes (Tesseract.js's WASM engine
// doesn't carry the native-library thread-safety issues that ruled out
// in-process threading on the Python/EasyOCR side).

import { createScheduler, createWorker } from "tesseract.js";
import { config } from "./config.js";

let scheduler = null;

export async function startPool() {
  scheduler = createScheduler();
  await Promise.all(
    Array.from({ length: config.ocrWorkers }, async () => {
      const worker = await createWorker(config.ocrLanguage);
      scheduler.addWorker(worker);
    })
  );
}

export async function stopPool() {
  if (scheduler) {
    await scheduler.terminate();
    scheduler = null;
  }
}

/** Runs OCR on one page image; returns { text, confidence, ocrSeconds }. confidence is normalized to 0-1 to match the Python endpoints' convention (Tesseract.js reports 0-100). */
export async function runOcr(imageBytes) {
  const start = process.hrtime.bigint();
  const {
    data: { text, confidence },
  } = await scheduler.addJob("recognize", imageBytes);
  const ocrSeconds = Number(process.hrtime.bigint() - start) / 1e9;
  return { text: text.trim(), confidence: confidence / 100, ocrSeconds };
}
