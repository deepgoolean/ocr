// Page splitting/classification for the PDF, mirroring app/pdf_paging.py:
// a page is "digital" (real embedded text, no OCR needed) only if it has
// enough extractable text AND no single embedded image covering roughly
// the full page — a short text watermark stamped over a scanned page
// would otherwise clear the char-count threshold and get OCR skipped
// entirely, silently dropping the page's real content.

import * as mupdf from "mupdf";
import fs from "fs/promises";
import path from "path";
import { config } from "./config.js";

function fullPageImageBBox(page) {
  const json = page.toStructuredText("preserve-images").asJSON();
  const blocks = JSON.parse(json).blocks || [];
  const pageBounds = page.getBounds();
  const pageArea = (pageBounds[2] - pageBounds[0]) * (pageBounds[3] - pageBounds[1]);
  if (pageArea <= 0) return null;

  for (const block of blocks) {
    if (block.type !== "image") continue;
    const { w, h } = block.bbox;
    if ((w * h) / pageArea >= config.fullPageImageAreaRatio) {
      return block.bbox;
    }
  }
  return null;
}

function renderPageToPng(page, dpi) {
  const zoom = dpi / 72;
  const pixmap = page.toPixmap(mupdf.Matrix.scale(zoom, zoom), mupdf.ColorSpace.DeviceRGB, false);
  try {
    return Buffer.from(pixmap.asPNG());
  } finally {
    pixmap.destroy();
  }
}

/**
 * Phase 1: classify every page and, for scanned pages, render + write its
 * image to tempDir — for the whole document, before any OCR starts.
 * Returns pages in order: { pageNumber, kind: "digital"|"ocr", text?, imagePath?, splitSeconds }.
 */
export async function splitPdfToTempImages(content, tempDir) {
  const doc = mupdf.Document.openDocument(content, "application/pdf");
  try {
    const numPages = doc.countPages();
    const pages = [];
    for (let i = 0; i < numPages; i++) {
      const start = process.hrtime.bigint();
      const page = doc.loadPage(i);
      const pageNumber = i + 1;
      try {
        const digitalText = page.toStructuredText().asText().trim();
        const imageBBox = fullPageImageBBox(page);

        if (digitalText.length >= config.digitalTextMinChars && imageBBox === null) {
          pages.push({
            pageNumber,
            kind: "digital",
            text: digitalText,
            splitSeconds: Number(process.hrtime.bigint() - start) / 1e9,
          });
          continue;
        }

        const pngBytes = renderPageToPng(page, config.dpi);
        const imagePath = path.join(tempDir, `page_${String(pageNumber).padStart(4, "0")}.png`);
        await fs.writeFile(imagePath, pngBytes);
        pages.push({
          pageNumber,
          kind: "ocr",
          imagePath,
          splitSeconds: Number(process.hrtime.bigint() - start) / 1e9,
        });
      } finally {
        page.destroy();
      }
    }
    return pages;
  } finally {
    doc.destroy();
  }
}
