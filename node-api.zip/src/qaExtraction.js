// Xenova/distilbert-base-cased-distilled-squad (transformers.js, ONNX) is
// extractive QA: it returns an exact text span from the document, never a
// generated/paraphrased answer, so it can't hallucinate facts that aren't
// there. Questions about plaintiff/defendant/case number/address are
// routed to the fields already extracted by the deterministic parsers
// (caseCaptionExtraction.js, caseInfoExtraction.js, keyValueExtraction.js)
// instead of asked fresh here, since this model was verified unreliable on
// those fields specifically — it latches onto the literal word "Plaintiff"
// wherever it appears (e.g. inside "Plaintiff's Attorney"). This model is
// reserved for genuinely open-ended questions those parsers don't cover.

import { pipeline } from "@huggingface/transformers";

const MODEL_NAME = "Xenova/distilbert-base-cased-distilled-squad";

let qaPipelinePromise = null;
function getQaPipeline() {
  if (!qaPipelinePromise) {
    qaPipelinePromise = pipeline("question-answering", MODEL_NAME, { dtype: "q8" });
  }
  return qaPipelinePromise;
}

export async function warmUp() {
  await getQaPipeline();
}

// Keyword-based rather than a fixed phrase: real questions vary a lot
// ("Who is the plaintiff?", "What is Plaintiff name?", "plaintiff's name")
// and a rigid phrase regex misses most of them. A question counts as
// asking for the party's identity if it mentions that party but not the
// other one, and isn't actually asking about something related but
// different (their attorney, address, etc. — those still go to the QA
// model, this parser doesn't cover them).
const PLAINTIFF_WORD_RE = /\bplaintiffs?\b/i;
const DEFENDANT_WORD_RE = /\bdefendants?\b/i;
const RELATED_FIELD_RE = /\b(attorney|counsel|lawyer|address|phone|email|represent\w*)\b/i;

function wantsPartyName(question, partyRe, otherRe) {
  return partyRe.test(question) && !otherRe.test(question) && !RELATED_FIELD_RE.test(question);
}

// Beyond plaintiff/defendant, other fields llmFieldExtraction.js already
// extracts (case number, address, etc.) are worth reusing rather than
// re-asking the small QA model — verified on a real filing where "What is
// Case Number?" got back the entire caption paragraph at confidence 0.
// Route matching questions to that already-extracted field value instead.
const FIELD_ROUTES = [
  { questionRe: /\bcase\s*(no\.?|number)\b/i, fieldKeyRe: /^case\s*(no\.?|number)$/i },
  { questionRe: /\baddress\b/i, fieldKeyRe: /address/i },
];

function findRoutedFieldAnswer(question, fields) {
  for (const route of FIELD_ROUTES) {
    if (!route.questionRe.test(question)) continue;
    const match = fields.find((f) => route.fieldKeyRe.test(f.key));
    if (match) return match.value;
  }
  return null;
}

// Clients sometimes send several questions joined into one string (e.g.
// comma-separated in a single form field) instead of repeating the
// "questions" field once per question. A genuine single question
// essentially never contains an internal "?", so splitting on "?" safely
// recovers the individual questions in that case while leaving true single
// questions untouched.
function splitCompoundQuestion(raw) {
  raw = raw.trim();
  if (!raw || !raw.includes("?")) return raw ? [raw] : [];

  const parts = raw.split("?");
  const trailing = parts.pop();
  const questions = parts
    .map((p) => p.trim().replace(/^[,;]+/, "").trim())
    .filter(Boolean)
    .map((q) => `${q}?`);
  const trailingClean = trailing.trim().replace(/^[,;]+/, "").trim();
  if (trailingClean) questions.push(trailingClean);
  return questions;
}

// WordPiece detokenization leaves stray spaces around punctuation (e.g.
// "$ 150, 000. 00") — tidy that up without touching the actual answer text.
// Numeric grouping ("150, 000. 00") needs spaces stripped on *both* sides
// of the comma/period, not just before it, since the tokenizer splits each
// digit group into its own piece and naive space-joining pads both sides.
// Hyphenated names ("Garcia - Wood") get the same treatment.
function cleanAnswerText(answer) {
  return answer
    .replace(/(\d)\s*([.,])\s*(\d)/g, "$1$2$3")
    .replace(/(\w)\s+-\s+(\w)/g, "$1-$2")
    .replace(/\s+([.,%)\]:;!?])/g, "$1")
    .replace(/([$(])\s+/g, "$1")
    .trim();
}

// Unlike Python's HF pipeline (max_seq_len/doc_stride), transformers.js's
// QA pipeline does NOT stride over long context automatically — it just
// silently truncates to the model's ~512-token window and answers from
// whatever that prefix happens to contain, verified empirically (it
// returned a near-zero-confidence wrong answer from filler text once the
// real answer sat past that point). Chunking manually with overlap and
// keeping the highest-scoring answer across chunks reproduces the Python
// side's coverage of the whole document.
const CONTEXT_CHUNK_CHARS = 1500;
const CONTEXT_CHUNK_OVERLAP = 200;

function chunkContext(text) {
  const chunks = [];
  let start = 0;
  while (start < text.length) {
    const end = Math.min(start + CONTEXT_CHUNK_CHARS, text.length);
    chunks.push(text.slice(start, end));
    if (end >= text.length) break;
    start = end - CONTEXT_CHUNK_OVERLAP;
  }
  return chunks;
}

// Verified on real filings where the model had no real answer (the
// question asked about a field the document doesn't contain, e.g. a street
// address on a filing that only has a legal property description): rather
// than a low-but-plausible-looking wrong guess, it returned an entire
// unrelated paragraph as the "answer" at confidence 0.0002-0.0003. Below
// this floor the raw span is more misleading than useful, so it's reported
// as not found instead — the confidence number alone doesn't stop a caller
// from just reading `answer` at face value.
const MIN_CONFIDENCE = 0.05;

async function answerFromModel(qa, question, text) {
  let best = null;
  for (const chunk of chunkContext(text)) {
    const result = await qa(question, chunk);
    if (!best || result.score > best.score) best = result;
  }
  return best;
}

export async function answerQuestions(text, questions, { fields = [] } = {}) {
  if (!text.trim() || !questions.length) return [];

  const expandedQuestions = questions.flatMap(splitCompoundQuestion);
  const qa = await getQaPipeline();
  const answers = [];
  const plaintiffField = fields.find((f) => f.key === "Plaintiff");
  const defendantField = fields.find((f) => f.key === "Defendant");

  for (const rawQuestion of expandedQuestions) {
    const question = rawQuestion.trim();
    if (!question) continue;

    if (wantsPartyName(question, PLAINTIFF_WORD_RE, DEFENDANT_WORD_RE) && plaintiffField) {
      answers.push({ question, answer: plaintiffField.value, confidence: 0.99 });
      continue;
    }
    if (wantsPartyName(question, DEFENDANT_WORD_RE, PLAINTIFF_WORD_RE) && defendantField) {
      answers.push({ question, answer: defendantField.value, confidence: 0.99 });
      continue;
    }

    const routedAnswer = findRoutedFieldAnswer(question, fields);
    if (routedAnswer) {
      answers.push({ question, answer: routedAnswer, confidence: 0.95 });
      continue;
    }

    const result = await answerFromModel(qa, question, text);
    // Chunked long documents can have the same answer span straddle
    // overlapping windows, and score aggregation isn't always a clean max —
    // clamp since a confidence over 1.0 is meaningless to a caller.
    const confidence = Math.min(Number(result.score.toFixed(4)), 1.0);
    answers.push({
      question,
      answer: confidence >= MIN_CONFIDENCE ? cleanAnswerText(result.answer) : "Not found in document",
      confidence,
    });
  }
  return answers;
}
