// Runs inside a forked child process (see gemma3nPool.js) so an OOM kill
// only takes down this one worker, not the whole server. Same isolation
// rationale as app/ocr_pool.py's ProcessPoolExecutor on the Python side —
// a heavy model crashing shouldn't take other routes down with it.
import { extractFieldsWithGemma, answerQuestionsWithGemma } from "./gemma3nExtraction.js";

process.on("message", async (msg) => {
  try {
    let result;
    if (msg.type === "extractFields") {
      result = await extractFieldsWithGemma(msg.text);
    } else if (msg.type === "answerQuestions") {
      result = await answerQuestionsWithGemma(msg.text, msg.questions);
    } else {
      throw new Error(`Unknown message type: ${msg.type}`);
    }
    process.send({ id: msg.id, ok: true, result });
  } catch (err) {
    process.send({ id: msg.id, ok: false, error: String(err?.message || err) });
  }
});
