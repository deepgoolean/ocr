import express from "express";
import multer from "multer";
import fs from "fs/promises";
import os from "os";
import path from "path";
import { config } from "./config.js";
import { splitPdfToTempImages } from "./pdfPaging.js";
import { startPool, stopPool, runOcr } from "./ocrPool.js";

const PDF_MAGIC = Buffer.from("%PDF");

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: config.maxUploadMb * 1024 * 1024 },
});

async function resolvePage(item) {
  const splitSeconds = Number(item.splitSeconds.toFixed(3));

  if (item.kind === "digital") {
    return {
      page_number: item.pageNumber,
      method: "digital",
      text: item.text,
      confidence: null,
      split_seconds: splitSeconds,
      ocr_seconds: 0,
      total_seconds: splitSeconds,
    };
  }

  const imageBytes = await fs.readFile(item.imagePath);
  const { text, confidence, ocrSeconds } = await runOcr(imageBytes);
  const roundedOcrSeconds = Number(ocrSeconds.toFixed(3));
  return {
    page_number: item.pageNumber,
    method: "ocr",
    text,
    confidence: Number(confidence.toFixed(4)),
    split_seconds: splitSeconds,
    ocr_seconds: roundedOcrSeconds,
    total_seconds: Number((splitSeconds + roundedOcrSeconds).toFixed(3)),
  };
}

async function extractText(filename, content) {
  const start = process.hrtime.bigint();
  const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "pdf_ocr_split_"));

  let pages;
  let splitPhaseSeconds;
  let ocrPhaseSeconds;
  try {
    const splitStart = process.hrtime.bigint();
    const tempPages = await splitPdfToTempImages(content, tempDir);
    splitPhaseSeconds = Number(process.hrtime.bigint() - splitStart) / 1e9;

    const ocrStart = process.hrtime.bigint();
    pages = await Promise.all(tempPages.map(resolvePage));
    ocrPhaseSeconds = Number(process.hrtime.bigint() - ocrStart) / 1e9;
  } finally {
    await fs.rm(tempDir, { recursive: true, force: true });
  }

  const orderedPages = [...pages].sort((a, b) => a.page_number - b.page_number);
  const fullText = orderedPages.map((p) => p.text).join("\n\n");
  const elapsed = Number(process.hrtime.bigint() - start) / 1e9;

  return {
    filename,
    num_pages: orderedPages.length,
    pages: orderedPages,
    full_text: fullText,
    split_phase_seconds: Number(splitPhaseSeconds.toFixed(3)),
    ocr_phase_seconds: Number(ocrPhaseSeconds.toFixed(3)),
    processing_time_seconds: Number(elapsed.toFixed(3)),
  };
}

const app = express();

app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

app.post("/extract-text-simple", upload.array("files"), async (req, res) => {
  const files = req.files || [];
  if (files.length === 0) {
    return res.status(400).json({ detail: "No files uploaded" });
  }

  const results = [];
  const errors = [];

  await Promise.all(
    files.map(async (file) => {
      if (!file.buffer.subarray(0, 4).equals(PDF_MAGIC)) {
        errors.push({ filename: file.originalname, error: "Not a valid PDF file" });
        return;
      }
      try {
        results.push(await extractText(file.originalname, file.buffer));
      } catch (exc) {
        errors.push({ filename: file.originalname, error: String(exc.message || exc) });
      }
    })
  );

  res.json({ results, errors });
});

// multer's fileSize limit surfaces as this error code rather than throwing
// inside the route handler above.
app.use((err, req, res, next) => {
  if (err && err.code === "LIMIT_FILE_SIZE") {
    return res.status(400).json({ detail: `File exceeds ${config.maxUploadMb}MB limit` });
  }
  next(err);
});

async function main() {
  await startPool();
  const server = app.listen(config.port, "0.0.0.0", () => {
    console.log(`Node OCR API listening on port ${config.port}`);
  });

  const shutdown = async () => {
    server.close();
    await stopPool();
    process.exit(0);
  };
  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
}

main();
