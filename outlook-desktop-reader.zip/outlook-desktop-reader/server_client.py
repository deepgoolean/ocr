"""
Connection to the Rule Management server (runs on another computer in the same LAN / Wi-Fi).

Only the Python standard library: nothing extra to install on the Windows PC.
Every call sends the connector key (made in the web panel: Outlook Desktop -> Connections) and a little
information about this PC (name, version, mode), so the web panel shows which PC is connected.

ServerUnavailable  the server could not be reached (network, server stopped, timeout): try again later
ServerError        the server answered with an error (bad key, template not active ...): show it
"""
from __future__ import annotations

import json
import mimetypes
import platform
import socket
import uuid
from email.message import EmailMessage
from email.utils import formataddr, format_datetime, parsedate_to_datetime
from datetime import datetime
from urllib import error, request

PROCESS_TIMEOUT = 900   # the Smart Analyzer can take minutes for an email with several PDFs
CALL_TIMEOUT = 30


class ServerUnavailable(Exception):
    pass


class ServerError(Exception):
    pass


def normalize_url(url: str) -> str:
    url = (url or "").strip().rstrip("/")
    if url and "://" not in url:
        url = "http://" + url
    if url.endswith("/api"):
        url = url[:-4]
    return url


class ServerClient:
    def __init__(self, url: str, key: str, version: str = "", mode: str = ""):
        self.url = normalize_url(url)
        self.key = (key or "").strip()
        self.device = {"computer": socket.gethostname(), "os": platform.platform(terse=True), "version": version, "mode": mode}

    @property
    def configured(self) -> bool:
        return bool(self.url and self.key)

    def _call(self, method: str, path: str, body=None, data: bytes | None = None, content_type: str | None = None,
              timeout: int = CALL_TIMEOUT):
        if not self.configured:
            raise ServerError("Server address and connector key are not set")
        headers = {"X-Connector-Key": self.key, "X-Device": json.dumps(self.device), "Accept": "application/json"}
        if body is not None:
            data, content_type = json.dumps(body).encode(), "application/json"
        if content_type:
            headers["Content-Type"] = content_type
        req = request.Request(self.url + path, data=data, method=method, headers=headers)
        try:
            with request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read()
        except error.HTTPError as exc:
            try:
                detail = json.loads(exc.read() or b"{}").get("detail")
            except ValueError:
                detail = None
            if exc.code in (502, 503, 504):
                raise ServerUnavailable(f"server busy or down (HTTP {exc.code})") from None
            raise ServerError(f"{detail or exc.reason} (HTTP {exc.code})") from None
        except (error.URLError, socket.timeout, TimeoutError, ConnectionError, OSError) as exc:
            reason = getattr(exc, "reason", exc)
            raise ServerUnavailable(f"cannot reach {self.url}: {reason}") from None
        try:
            return json.loads(raw or b"null")
        except ValueError:
            raise ServerError("the server sent something that is not JSON (wrong address?)") from None

    # ---- calls -----------------------------------------------------------------
    def ping(self) -> dict:
        return self._call("GET", "/api/connector/ping")

    def templates(self) -> list:
        return self._call("GET", "/api/connector/templates")

    def template_bundle(self, template_id: int) -> dict:
        return self._call("GET", f"/api/connector/templates/{int(template_id)}")

    def start_run(self, kind: str, mode: str, folders: list, date_from: str = None, date_to: str = None) -> dict:
        return self._call("POST", "/api/connector/runs", {"kind": kind, "mode": mode, "folders": folders,
                                                          "date_from": date_from, "date_to": date_to})

    def update_run(self, run_id: int, status: str = None, note: str = None) -> dict:
        return self._call("PATCH", f"/api/connector/runs/{int(run_id)}", {"status": status, "note": note})

    def process(self, eml: bytes, meta: dict) -> dict:
        boundary = uuid.uuid4().hex
        parts = [
            (f'--{boundary}\r\nContent-Disposition: form-data; name="meta"\r\n'
             f"Content-Type: application/json\r\n\r\n").encode() + json.dumps(meta).encode() + b"\r\n",
            (f'--{boundary}\r\nContent-Disposition: form-data; name="email_file"; filename="email.eml"\r\n'
             f"Content-Type: message/rfc822\r\n\r\n").encode() + eml + b"\r\n",
            f"--{boundary}--\r\n".encode(),
        ]
        return self._call("POST", "/api/connector/process", data=b"".join(parts),
                          content_type=f"multipart/form-data; boundary={boundary}", timeout=PROCESS_TIMEOUT)

    def add_item(self, body: dict) -> dict:
        return self._call("POST", "/api/connector/items", body)

    def finish_item(self, item_id: int, body: dict) -> dict:
        return self._call("PATCH", f"/api/connector/items/{int(item_id)}", body)


def build_eml(msg: dict, attachments: list) -> bytes:
    """
    The email as a standard .eml (works with real Outlook and demo data alike).
    attachments: [(file name, bytes)]. Only what the server needs: headers, text body, attachments.
    """
    m = EmailMessage()
    m["Subject"] = (msg.get("subject") or "").replace("\r", " ").replace("\n", " ")
    m["From"] = formataddr((msg.get("sender") or "", msg.get("sender_email") or ""))
    to = [formataddr((r.get("name") or "", r.get("address") or "")) for r in msg.get("recipients") or []
          if r.get("type", "To") != "Bcc" and r.get("address") and "@" in str(r.get("address"))]
    if to:
        m["To"] = ", ".join(to)
    when = str(msg.get("received") or msg.get("sent") or "")
    try:
        m["Date"] = format_datetime(datetime.strptime(when[:16], "%Y-%m-%d %H:%M").astimezone())
    except ValueError:
        try:
            m["Date"] = format_datetime(parsedate_to_datetime(when))
        except (TypeError, ValueError):
            pass  # no date: the server uses the time it received the email
    m.set_content(msg.get("body") or "")
    for name, data in attachments:
        kind = mimetypes.guess_type(name)[0] or "application/octet-stream"
        main, sub = kind.split("/", 1)
        m.add_attachment(data, maintype=main, subtype=sub, filename=name)
    return m.as_bytes()
