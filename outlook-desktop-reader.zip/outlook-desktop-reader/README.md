# Outlook Desktop Reader

A small standalone tool that shows **all email data of Classic Outlook for Windows**, account by
account and folder by folder, in your browser. It also exports everything to CSV / JSON.

- **Read-only browsing.** Viewing never changes, moves, marks read or sends anything in Outlook. Only the optional **Automation** in Live mode acts on Outlook (see below).
- **Local only.** The viewer listens on `127.0.0.1` and no data leaves the PC.
- **Lightweight.** Python plus two packages (`pywin32`, `pypdf`), no database server, no framework.
- **Standalone or connected.** Rules arrive as a JSON file, or over the network from the Rule Management server (see below).

## What it shows
| Level | Data |
|---|---|
| Accounts | Every Outlook store: each account's mailbox (Exchange / Microsoft 365, IMAP, POP3), shared mailboxes, `.pst` / `.ost` data files. Shows name, e-mail, type, file path, default account. |
| Folders | Full folder tree per account (Inbox, sub-folders, Sent, Archive …) with total and unread counts. |
| Email list | From, e-mail, subject, received date, size, unread, attachments, categories. Search by subject / sender / date / unread, 50 per page, CSV of the folder. |
| One email | From, To, Cc, Bcc, dates, importance, categories, text body, HTML body (safe view), internet headers, attachments (download), save as `.msg`. |

## Automation: templates from Rule Management
A template holds its rules and its "Applies to" filters. It is built per client in Rule Management, exported to a file, and run here on new emails.

1. **Export:** in Rule Management, *Rule Templates → Export for Outlook* on an ACTIVE template. The file contains its ACTIVE rules, order, thresholds and filters.
2. **Import:** click **Automation** in the top bar and choose the file, or copy it into `automation_data\import\`; it is imported by itself at the next check. Damaged or hand-edited files are refused. You can import several templates of one client; importing a template again updates it. An email runs under the first template that applies to it.
3. **Watch:** tick the Inboxes, or add the folder open in the main screen. Only emails arriving after that are processed, each one once.
4. **Mode:** starts as **Dry run** (checks and logs only). Read the Activity list, then switch to **Live**.

| Rule action | In Live mode |
|---|---|
| TAG, CATEGORY | Adds Outlook categories to the email |
| RENAME, MOVE | Saves a copy of the PDF attachment to disk under the chosen folder, with the new name. The email is not changed. |
| MOVE_EMAIL | Moves the email to that folder under the account root; the folder is created if missing |
| FORWARD | Sends a real forward, only after ticking *Allow sending real forwards*. Otherwise logged as not sent. |

The first template, or one with a new forward address, switches Live back to Dry run and turns forwarding off, so it is reviewed first. Other imports keep running. Templates of another client are refused until the current ones are removed.

**How matching differs from Rule Management.** This PC has no Smart Analyzer and no vectors, so results can differ:
- Vector similarity is left out of the score. Scoring is always the Classic score.
- Document type and intent match when their name appears in the subject, body or PDF text.
- Case number, hearing date, court and state are read with simple text patterns.
- Scanned PDFs have no text here (no OCR). Bot role limits are not checked.

Each imported rule shows **FULL**, **APPROXIMATE** (with the reasons) or **NOT_RUNNABLE** (never runs). Use **Test rules on the selected email** and Dry run before going Live.

**Logs.** The **Activity** list in Automation shows each email with its result, template and processing time. Open a row to see each step: which templates applied, which PDFs were read, each rule's score, and each action's outcome. You can filter by result (or *Problems only*), search, pick dates and download a CSV. Program events are listed too: start, imports, removed templates, settings changes and lost Outlook connections. The same log is written to one text file per day in `automation_data\logs\`. Email bodies and PDF text are not logged. An email that ends in ERROR is not tried again automatically.

Outlook and this program must both be open for automation to run. Emails that arrived while it was closed are processed at the next start. Data (templates, settings, activity with subjects and senders, saved PDFs) stays in `automation_data\` next to the program; keep that folder private. Activity and log files older than 90 days are removed automatically.

Tests (no Outlook needed): `python -m unittest discover -s tests`

## Connected to the Rule Management server (LAN / Wi-Fi)
Rule Management runs on the Mac, this tool on the Windows PC, both in the same network.

1. **Mac:** start with `./start.sh` (the backend listens on the network and prints the address, e.g. `http://192.168.1.3:8000`).
   Allow incoming connections for Python if the macOS firewall asks.
2. **Web panel → Outlook Desktop → Connections → New key** (one per PC; shown once).
3. **PC:** Automation → *Connection to Rule Management*: server address + key → *Save* → *Test connection*.
4. **Templates on the server** → *Import* (or *Update all* after rules changed). File import still works.
5. Choose the folders, choose **Rule Management server** as engine, Dry run or Live.
6. **New emails** are processed as they arrive. **Process old emails**: choose folders, a from / to date and time, Dry run or Live,
   and optionally "also emails processed before".

With the server engine each email (text + attachments) goes to the server: it runs the Smart Analyzer (model → other models →
regex fallback) and the template's rules, and sends back the actions. This PC carries them out in Outlook and reports the result.
Expect 15 s to several minutes per email, depending on the model and the Mac.

**Reports.** Each monitoring day and each old-email job is one report: counts per result and every email with its steps
(template, Smart Analyzer per document, rule, each action). They are under *Reports* here, and in the web panel under
*Outlook Desktop → Reports* (with a link to the email and its analysis). CSV in both places.

If the server cannot be reached, emails wait (they are not marked as done) and are processed when it is back; an old-email job stops
and can be started again. The key is stored in `automation_data\settings.json`; never shown again in the screen; revoke it in the web panel if the PC is lost.

## Requirements (the Windows PC)
- Windows 10 / 11 with **Classic Outlook** (Outlook 2016 / 2019 / 2021 / Microsoft 365 desktop), installed, set up and signed in.
  The **"New Outlook"** app and Outlook on the web are **not** supported (Microsoft removed the automation interface from them).
- **Python 3.8 or newer** from https://www.python.org/downloads/windows/ (tick **"Add python.exe to PATH"**),
  or use the `.exe` (see below), which needs no Python.
- Internet once, to install `pywin32` and `pypdf` (or see "Offline PC").

## Run
1. Copy / unzip the `outlook-desktop-reader` folder anywhere, e.g. `C:\Tools\outlook-desktop-reader`.
2. Open Outlook and let it finish loading.
3. Double-click **`run.bat`**.
   - The first time, it creates `.venv` and installs `pywin32` (about 1 minute).
   - The browser opens **http://127.0.0.1:8765**.
4. Click an account, then a folder, then an email.
5. Stop: close the black window or press `Ctrl+C`.

The same from a Command Prompt in the folder:
```bat
run.bat                          :: viewer on http://127.0.0.1:8765
run.bat --port 9000              :: other port
run.bat --no-browser             :: do not open the browser
run.bat export                   :: all accounts -> .\export\<account>\emails.csv + folders.json
run.bat export --with-body       :: also the text body (emails.json), slower
run.bat export --account intake  :: only accounts whose name / e-mail contains "intake"
run.bat export --max 500         :: newest 500 emails per folder
```
Manual setup without `run.bat`:
```bat
py -3 -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python app.py
```

## Try it without Outlook (demo data)
Any computer (Windows, macOS, Linux) with Python 3.8+:
```bash
python3 app.py --demo            # Windows: run_demo.bat
```

## No Python on the target PC: build an .exe
On one Windows PC where `run.bat` works, double-click **`build_exe.bat`**. It creates
`dist\OutlookReader.exe`. Copy only that file to the other PC and double-click it (Outlook must be
installed there). Command line: `OutlookReader.exe export --out C:\export`.

## Offline PC (no internet)
On a PC with internet and the **same Python version**:
`py -3 -m pip download -r requirements.txt -d wheels`. Copy the `wheels` folder next to `run.bat`;
`run.bat` installs from it automatically. Or simply use the `.exe`.

## Troubleshooting
| Message | Fix |
|---|---|
| `Cannot open Outlook … Server execution failed` | Do **not** "Run as administrator". Outlook and this tool must run as the same user, same level. Start Outlook first. |
| `pywin32 is missing` | `run.bat` installs it; manually: `.venv\Scripts\python -m pip install pywin32` |
| Outlook shows "A program is trying to access e-mail address information" | Outlook's security prompt (shown when antivirus is not recognised). Click **Allow** (e.g. 10 minutes), or ask IT to allow programmatic access in Outlook → File → Options → Trust Center. |
| `Python was not found` (opens Microsoft Store) | Install Python from python.org with "Add to PATH", or use the `.exe`. |
| Account shows no folders / errors | Shared mailboxes without permission, or an Exchange account working offline: open it once in Outlook. |
| Port in use | `run.bat --port 9000` |
| Slow on very large folders | Use search filters, or paging. The list reads only the needed columns, but the first page of a 100k-item folder can still take a few seconds. |

## Files
| File | Purpose |
|---|---|
| `app.py` | Local web server, API and export command |
| `outlook_source.py` | Reads Outlook through COM (accounts, folders, emails, attachments) |
| `demo_source.py` | Fake data with the same interface (`--demo`) |
| `static/index.html` | The viewer page |
| `run.bat` / `run_demo.bat` / `build_exe.bat` | Windows launchers |
| `requirements.txt` | `pywin32` (Windows only) |
