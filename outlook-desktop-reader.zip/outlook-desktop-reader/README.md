# Outlook Desktop Reader

A small standalone tool that shows **all email data of Classic Outlook for Windows**, account by
account and folder by folder, in your browser. It also exports everything to CSV / JSON.

- **Read-only.** Nothing is changed, moved, marked read or sent in Outlook.
- **Local only.** The viewer listens on `127.0.0.1` and no data leaves the PC.
- **Lightweight.** Python plus one package (`pywin32`), no database, no framework.
- **Standalone.** It is not connected to any other application.

## What it shows
| Level | Data |
|---|---|
| Accounts | Every Outlook store: each account's mailbox (Exchange / Microsoft 365, IMAP, POP3), shared mailboxes, `.pst` / `.ost` data files. Shows name, e-mail, type, file path, default account. |
| Folders | Full folder tree per account (Inbox, sub-folders, Sent, Archive …) with total and unread counts. |
| Email list | From, e-mail, subject, received date, size, unread, attachments, categories. Search by subject / sender / date / unread, 50 per page, CSV of the folder. |
| One email | From, To, Cc, Bcc, dates, importance, categories, text body, HTML body (safe view), internet headers, attachments (download), save as `.msg`. |

## Requirements (the Windows PC)
- Windows 10 / 11 with **Classic Outlook** (Outlook 2016 / 2019 / 2021 / Microsoft 365 desktop), installed, set up and signed in.
  The **"New Outlook"** app and Outlook on the web are **not** supported (Microsoft removed the automation interface from them).
- **Python 3.8 or newer** from https://www.python.org/downloads/windows/ (tick **"Add python.exe to PATH"**),
  or use the `.exe` (see below), which needs no Python.
- Internet once, to install `pywin32` (or see "Offline PC").

## Run
1. Copy / unzip the `outlook-desktop-reader` folder anywhere, e.g. `C:\Tools\outlook-desktop-reader`.
2. Open Outlook and let it finish loading.
3. Double-click **`run.bat`**.
   - The first time, it creates `.venv` and installs `pywin32` (about 1 minute).
   - The browser opens **http://127.0.0.1:8765**.
4. Click an account, then a folder, then an email.
5. Stop: close the black window or press `Ctrl+C`.

The same from a Command Prompt in the folder:
```bat
run.bat                          :: viewer on http://127.0.0.1:8765
run.bat --port 9000              :: other port
run.bat --no-browser             :: do not open the browser
run.bat export                   :: all accounts -> .\export\<account>\emails.csv + folders.json
run.bat export --with-body       :: also the text body (emails.json), slower
run.bat export --account intake  :: only accounts whose name / e-mail contains "intake"
run.bat export --max 500         :: newest 500 emails per folder
```
Manual setup without `run.bat`:
```bat
py -3 -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python app.py
```

## Try it without Outlook (demo data)
Any computer (Windows, macOS, Linux) with Python 3.8+:
```bash
python3 app.py --demo            # Windows: run_demo.bat
```

## No Python on the target PC: build an .exe
On one Windows PC where `run.bat` works, double-click **`build_exe.bat`**. It creates
`dist\OutlookReader.exe`. Copy only that file to the other PC and double-click it (Outlook must be
installed there). Command line: `OutlookReader.exe export --out C:\export`.

## Offline PC (no internet)
On a PC with internet and the **same Python version**:
`py -3 -m pip download pywin32 -d wheels`. Copy the `wheels` folder next to `run.bat`;
`run.bat` installs from it automatically. Or simply use the `.exe`.

## Troubleshooting
| Message | Fix |
|---|---|
| `Cannot open Outlook … Server execution failed` | Do **not** "Run as administrator". Outlook and this tool must run as the same user, same level. Start Outlook first. |
| `pywin32 is missing` | `run.bat` installs it; manually: `.venv\Scripts\python -m pip install pywin32` |
| Outlook shows "A program is trying to access e-mail address information" | Outlook's security prompt (shown when antivirus is not recognised). Click **Allow** (e.g. 10 minutes), or ask IT to allow programmatic access in Outlook → File → Options → Trust Center. |
| `Python was not found` (opens Microsoft Store) | Install Python from python.org with "Add to PATH", or use the `.exe`. |
| Account shows no folders / errors | Shared mailboxes without permission, or an Exchange account working offline: open it once in Outlook. |
| Port in use | `run.bat --port 9000` |
| Slow on very large folders | Use search filters, or paging. The list reads only the needed columns, but the first page of a 100k-item folder can still take a few seconds. |

## Files
| File | Purpose |
|---|---|
| `app.py` | Local web server, API and export command |
| `outlook_source.py` | Reads Outlook through COM (accounts, folders, emails, attachments) |
| `demo_source.py` | Fake data with the same interface (`--demo`) |
| `static/index.html` | The viewer page |
| `run.bat` / `run_demo.bat` / `build_exe.bat` | Windows launchers |
| `requirements.txt` | `pywin32` (Windows only) |
