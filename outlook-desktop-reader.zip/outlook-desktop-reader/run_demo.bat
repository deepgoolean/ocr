@echo off
rem Same screens with fake data (no Outlook needed).
cd /d "%~dp0"
where py >nul 2>nul && (py -3 app.py --demo & exit /b)
python app.py --demo
