"""
Local rule engine for Outlook automation: decides which imported rule matches an email and what
its actions would do. No Outlook, no network, no database here (easy to test on any OS).

The logic follows Rule Management (backend/app/services/rule_engine.py, CLASSIC score). The difference:
this PC has no Smart Analyzer and no vectors, so
  - vector similarity is left out of the score
  - document type / intent match when their name appears in the text (approximate)
  - case number, hearing date, court and state are read with simple patterns
Each rule gets a "compatibility" on import so this is visible: FULL / APPROXIMATE / NOT_RUNNABLE.
"""
from __future__ import annotations

import hashlib
import json
import re
from datetime import date, datetime, timedelta
from email.utils import getaddresses, parseaddr

BUNDLE_FORMAT = "rule-management-template"
BUNDLE_VERSION = 2
CONDITION_BONUS = 0.05
LOCAL_FIELDS = {"subject", "sender", "sender_email", "recipients", "file_name", "source", "text", "document_text",
                "page_count", "case_number", "hearing_date", "court", "state", "month", "year", "date",
                "document_type", "intent"}
STATES = {"alabama": "AL", "alaska": "AK", "arizona": "AZ", "arkansas": "AR", "california": "CA", "colorado": "CO",
          "connecticut": "CT", "delaware": "DE", "florida": "FL", "georgia": "GA", "hawaii": "HI", "idaho": "ID",
          "illinois": "IL", "indiana": "IN", "iowa": "IA", "kansas": "KS", "kentucky": "KY", "louisiana": "LA",
          "maine": "ME", "maryland": "MD", "massachusetts": "MA", "michigan": "MI", "minnesota": "MN",
          "mississippi": "MS", "missouri": "MO", "montana": "MT", "nebraska": "NE", "nevada": "NV",
          "new hampshire": "NH", "new jersey": "NJ", "new mexico": "NM", "new york": "NY", "north carolina": "NC",
          "north dakota": "ND", "ohio": "OH", "oklahoma": "OK", "oregon": "OR", "pennsylvania": "PA",
          "rhode island": "RI", "south carolina": "SC", "south dakota": "SD", "tennessee": "TN", "texas": "TX",
          "utah": "UT", "vermont": "VT", "virginia": "VA", "washington": "WA", "west virginia": "WV",
          "wisconsin": "WI", "wyoming": "WY"}


# --------------------------------------------------------------------------- #
# Bundle
# --------------------------------------------------------------------------- #
def checksum(bundle: dict) -> str:
    """Detects damaged or hand-edited files. Same calculation as the Rule Management export."""
    core = {k: bundle.get(k) for k in ("client", "template", "filters", "rules")}
    return "sha256:" + hashlib.sha256(json.dumps(core, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def validate_bundle(bundle) -> None:
    if not isinstance(bundle, dict) or bundle.get("format") != BUNDLE_FORMAT:
        raise ValueError("This is not a template file. In Rule Management use Rule Templates → Export for Outlook.")
    if bundle.get("format_version") != BUNDLE_VERSION:
        raise ValueError(f"Unsupported file version {bundle.get('format_version')}; update this tool.")
    if not isinstance(bundle.get("rules"), list) or not (bundle.get("template") or {}).get("id"):
        raise ValueError("The file has no template or rule list.")
    if bundle.get("checksum") != checksum(bundle):
        raise ValueError("Checksum does not match: the file was damaged or edited. Export it again.")


def forward_recipients(templates: list) -> set:
    return {t.lower() for b in templates for r in b.get("rules", []) for a in r.get("actions") or [] if a.get("type") == "FORWARD"
            for t in _addresses(a.get("params", {}).get("to"))}


def compatibility(rule: dict) -> dict:
    """How faithfully this rule can run on this PC."""
    notes = []
    conds = list(rule.get("conditions") or []) + list(rule.get("inclusion_rules") or []) + list(rule.get("exclusion_rules") or [])
    unavailable = sorted({c.get("field") for c in conds if c.get("field") not in LOCAL_FIELDS})
    usable = bool(rule.get("keywords") or rule.get("document_types") or rule.get("intents"))
    if rule.get("use_vector"):
        notes.append("vector similarity is not available here: left out of the score")
    if rule.get("document_types") or rule.get("intents"):
        notes.append("document type / intent are matched by their name in the text")
    if unavailable:
        notes.append(f"fields not available here (always empty): {', '.join(str(u) for u in unavailable)}")
    if not rule.get("actions"):
        return {"level": "NOT_RUNNABLE", "notes": ["the rule has no actions"]}
    if not usable:
        return {"level": "NOT_RUNNABLE", "notes": notes + ["no keywords, document type or intent to score on here"]}
    return {"level": "APPROXIMATE" if notes else "FULL", "notes": notes}


# --------------------------------------------------------------------------- #
# Field extraction from plain text
# --------------------------------------------------------------------------- #
_DATE = r"(\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{2,4}|[A-Z][a-z]+\.? \d{1,2},? \d{4})"


def extract_fields(text: str) -> dict:
    text = text or ""
    case = re.search(r"\bcase\s*(?:no\.?|number|num\.?|#)?\s*[:#]?\s*([A-Z0-9][A-Z0-9-]*\d[A-Z0-9-]*)", text, re.I) \
        or re.search(r"\b(\d{2,4}-[A-Z]{1,5}-\d{2,}[A-Z0-9-]*)\b", text)
    hearing = re.search(r"hearing[^\n]{0,40}?" + _DATE, text, re.I)
    court = re.search(r"((?:[A-Z][\w.'-]* )*(?:Court|COURT)\b[^\n,.;]{0,60})", text)
    low = text.lower()
    state = next((c for n, c in sorted(STATES.items(), key=lambda x: -len(x[0]))
                  if re.search(rf"\b(?:state of|county,|courts? of) {n}\b|\b{n} (?:circuit|district|superior|supreme) court\b", low)), None)
    if state is None:
        m = re.search(r"\bcounty,\s*([A-Z]{2})\b", text, re.I)
        state = m[1].upper() if m and m[1].upper() in STATES.values() else None
    return {"case_number": case[1] if case else None, "hearing_date": hearing[1] if hearing else None,
            "court": court[1].strip() if court else None, "state": state}


# --------------------------------------------------------------------------- #
# Conditions (same behaviour as Rule Management)
# --------------------------------------------------------------------------- #
def parse_date(value):
    if not value:
        return None
    text = str(value).strip()
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%B %d, %Y", "%b %d, %Y", "%Y/%m/%d"):
        try:
            return datetime.strptime(text[:20], fmt).date()
        except ValueError:
            continue
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", text)
    return date(int(m[1]), int(m[2]), int(m[3])) if m else None


def resolve_date(expected):
    text = str(expected or "").strip().lower().replace(" ", "")
    m = re.fullmatch(r"today(?:([+-])(\d+))?", text)
    if m:
        return date.today() + timedelta(days=int(m[2] or 0) * (-1 if m[1] == "-" else 1))
    return parse_date(expected)


def check_date_condition(op, value, expected) -> bool:
    d = parse_date(value)
    if d is None:
        return False
    today = date.today()
    if op == "date_is_past":
        return d < today
    if op == "date_is_future":
        return d > today
    if op in ("date_within_next", "date_within_past"):
        try:
            n = int(str(expected).strip())
        except (TypeError, ValueError):
            return False
        return today <= d <= today + timedelta(days=n) if op == "date_within_next" else today - timedelta(days=n) <= d <= today
    target = resolve_date(expected)
    if target is None:
        return False
    return {"date_on": d == target, "date_before": d < target, "date_after": d > target,
            "date_on_or_before": d <= target, "date_on_or_after": d >= target}.get(op, False)


def check_condition(cond: dict, fields: dict) -> bool:
    value = fields.get(cond.get("field"))
    expected = cond.get("value")
    op = cond.get("operator", "exists")
    if op.startswith("date_"):
        return check_date_condition(op, value, expected)
    text = str(value or "").lower()
    exp = str(expected or "").lower()
    if op == "exists":
        return value not in (None, "")
    if op == "not_exists":
        return value in (None, "")
    if op == "equals":
        return text == exp
    if op == "not_equals":
        return text != exp
    if op == "contains":
        return exp in text
    if op == "not_contains":
        return exp not in text
    if op == "regex":
        try:
            return re.search(str(expected or ""), str(value or ""), re.IGNORECASE) is not None
        except re.error:
            return False
    if op == "starts_with":
        return text.startswith(exp)
    if op == "ends_with":
        return text.endswith(exp)
    if op in ("contains_any", "contains_all"):
        words = [w.strip().lower() for w in (expected if isinstance(expected, list) else str(expected or "").split(","))]
        words = [w for w in words if w]
        hits = [w in text for w in words]
        return bool(words) and (any(hits) if op == "contains_any" else all(hits))
    if op == "in_range":
        try:
            lo, hi = (float(x) for x in (expected if isinstance(expected, list) else str(expected).split(","))[:2])
            return lo <= float(value) <= hi
        except (TypeError, ValueError):
            return False
    if op in ("is_true", "is_false"):
        truthy = text in ("true", "1", "yes", "y") or (value not in (None, "", False, 0, "false", "no") and text not in ("false", "0", "no"))
        return truthy if op == "is_true" else not truthy
    if op in ("days_until_lte", "days_until_gte"):
        d = parse_date(value)
        try:
            n = int(str(expected).strip())
        except (TypeError, ValueError):
            return False
        if d is None:
            return False
        days = (d - date.today()).days
        return days <= n if op == "days_until_lte" else days >= n
    if op in ("gte", "lte"):
        try:
            a, b = float(value), float(expected)
        except (TypeError, ValueError):
            a, b = str(value or ""), str(expected or "")
            if not a:
                return False
        return a >= b if op == "gte" else a <= b
    if op == "in":
        options = expected if isinstance(expected, list) else str(expected or "").split(",")
        return text in [str(o).strip().lower() for o in options]
    return False


# --------------------------------------------------------------------------- #
# Email -> what a rule looks at
# --------------------------------------------------------------------------- #
def _date_fields() -> dict:
    now = datetime.now()
    return {"month": now.strftime("%B"), "year": now.strftime("%Y"), "date": now.strftime("%Y-%m-%d")}


def _base_fields(msg: dict) -> dict:
    recipients = ", ".join(r.get("address") or r.get("name") or "" for r in msg.get("recipients") or [])
    return {"subject": msg.get("subject"), "sender": f"{msg.get('sender') or ''} <{msg.get('sender_email') or ''}>",
            "sender_email": msg.get("sender_email"), "recipients": recipients, **_date_fields()}


def build_documents(msg: dict, pdfs: list) -> list:
    """pdfs = [{"index", "file_name", "text", "page_count"}]. The body is a document like in Rule Management."""
    body = {"source": "EMAIL_BODY", "file_name": "email body", "text": msg.get("body") or "", "index": None, "page_count": None}
    return [body] + [{"source": "ATTACHMENT", **p} for p in pdfs]


def document_subject(msg: dict, doc: dict) -> dict:
    text = f"{msg.get('subject') or ''} {doc['file_name']} {doc['text']}"
    fields = {**_base_fields(msg), **extract_fields(f"{msg.get('subject') or ''}\n{doc['text']}"),
              "file_name": doc["file_name"], "source": doc["source"], "text": doc["text"], "page_count": doc.get("page_count")}
    return {"fields": fields, "text": text.lower(), "documents": [doc]}


def email_subject(msg: dict, docs: list) -> dict:
    ordered = sorted(docs, key=lambda d: d["source"] == "EMAIL_BODY")  # PDF values win over the body
    fields = {**_base_fields(msg), "source": "EMAIL", "text": "\n\n".join(d["text"] for d in ordered)}
    for d in ordered:
        for k, v in extract_fields(d["text"]).items():
            fields[k] = fields.get(k) or v
    for k, v in extract_fields(msg.get("subject") or "").items():
        fields[k] = fields.get(k) or v
    pdfs = [d for d in docs if d["source"] != "EMAIL_BODY"]
    fields["file_name"] = pdfs[0]["file_name"] if pdfs else msg.get("subject")
    text = f"{msg.get('subject') or ''} " + " ".join(f"{d['file_name']} {d['text']}" for d in ordered)
    return {"fields": fields, "text": text.lower(), "documents": pdfs or docs}


def _label_hits(labels: list, text: str) -> list:
    return [x for x in labels if x and str(x).replace("_", " ").lower() in text.replace("_", " ")]


def evaluate(rule: dict, subj: dict) -> dict:
    fields, text = dict(subj["fields"]), subj["text"]
    parts, blocked = {}, []
    if rule.get("document_types"):
        hits = _label_hits(rule["document_types"], text)
        parts["document_type"] = 1.0 if hits else 0.0
        fields["document_type"] = hits[0] if hits else None
        if not hits:
            blocked.append("document type does not match")
    if rule.get("intents"):
        hits = _label_hits(rule["intents"], text)
        parts["intent"] = 1.0 if hits else 0.0
        fields["intent"] = hits[0] if hits else None
    if rule.get("keywords"):
        found = [k for k in rule["keywords"] if k.lower() in text]
        missing = [k for k in rule["keywords"] if k not in found]
        if rule.get("keyword_mode") == "all":
            parts["keywords"] = len(found) / len(rule["keywords"])
            if missing:
                blocked.append(f"missing keywords: {missing}")
        else:
            parts["keywords"] = 1.0 if found else 0.0
    excluded = [k for k in rule.get("exclude_keywords") or [] if k.lower() in text]
    if excluded:
        blocked.append(f"excluded keywords found: {excluded}")
    bonus = 0.0
    for cond in rule.get("conditions") or []:
        ok = check_condition(cond, fields)
        if not ok and cond.get("required"):
            blocked.append(f"required condition failed: {cond.get('field')} {cond.get('operator')} {cond.get('value') or ''}".strip())
        elif ok and not cond.get("required"):
            bonus += CONDITION_BONUS
    rule_fields = {**fields, "document_text": text}
    inclusion = [check_condition(c, rule_fields) for c in rule.get("inclusion_rules") or []]
    if inclusion and not any(inclusion):
        blocked.append("no inclusion rule matched")
    if any(check_condition(c, rule_fields) for c in rule.get("exclusion_rules") or []):
        blocked.append("an exclusion rule matched")
    if not parts:
        blocked.append("nothing to score on this PC")
    score = round(min(1.0, (sum(parts.values()) / len(parts) if parts else 0.0) + bonus), 4)
    threshold = rule.get("confidence_threshold")
    threshold = 0.6 if threshold is None else threshold
    return {"matched": not blocked and score >= threshold, "score": score, "threshold": threshold,
            "blocked_by": blocked, "parts": parts, "fields": fields}


# --------------------------------------------------------------------------- #
# Template filters ("applies to")
# --------------------------------------------------------------------------- #
def address_allowed(address: str, allowed: list) -> bool:
    address = (parseaddr(address or "")[1] or address or "").lower()
    for item in allowed:
        item = item.strip().lower()
        if not item:
            continue
        if "@" in item and not item.startswith("@"):
            if address == item:
                return True
        elif address.endswith(item if item.startswith("@") else "@" + item) or address.endswith("." + item.lstrip("@")):
            return True
    return False


def _folder_ok(folder: str, wanted: list) -> bool:
    f = (folder or "").replace("\\", "/").strip("/").lower()
    for w in wanted:
        w = w.replace("\\", "/").strip("/").lower()
        if f and w and (f == w or f.startswith(w + "/") or f.endswith("/" + w)):
            return True
    return False


def filter_skip(filters: dict, msg: dict, folder: str, account_email: str) -> str | None:
    """Reason the email is outside the exported template, or None."""
    f = filters or {}
    if f.get("mailbox_emails") and (account_email or "").lower() not in [m.lower() for m in f["mailbox_emails"]]:
        return "mailbox is not in the template"
    if f.get("folders") and not _folder_ok(folder, f["folders"]):
        return f"folder '{folder}' is not in the template"
    sender = msg.get("sender_email") or ""
    if f.get("sender_whitelist") and not address_allowed(sender, f["sender_whitelist"]):
        return "sender not in the template's allow list"
    if f.get("sender_blacklist") and address_allowed(sender, f["sender_blacklist"]):
        return "sender is on the template's block list"
    if f.get("recipient_filters"):
        if not any(address_allowed(r.get("address") or "", f["recipient_filters"]) for r in msg.get("recipients") or []):
            return "no recipient matches the template"
    if f.get("subject_keywords") and not any(k.lower() in (msg.get("subject") or "").lower() for k in f["subject_keywords"]):
        return "subject has none of the template keywords"
    return None


def body_filter_skip(filters: dict, docs: list) -> str | None:
    words = (filters or {}).get("body_keywords")
    if words:
        text = " ".join(d["text"] for d in docs).lower()
        if not any(k.lower() in text for k in words):
            return "body / documents have none of the template keywords"
    return None


# --------------------------------------------------------------------------- #
# Actions
# --------------------------------------------------------------------------- #
def render(template: str, fields: dict) -> str:
    def repl(m):
        val = fields.get(m.group(1))
        return str(val) if val not in (None, "") else "UNKNOWN"
    return re.sub(r"\{(\w+)\}", repl, template or "")


def safe_name(name: str) -> str:
    return re.sub(r'[<>:"/\\|?*\n\r\t]+', "_", name).strip(" .") or "file"


def folder_parts(folder: str) -> list:
    return [safe_name(p) for p in re.split(r"[\\/]+", folder or "") if p and p not in (".", "..")]


def _addresses(to) -> list:
    raw = ", ".join(to) if isinstance(to, list) else str(to or "")
    return [a for _, a in getaddresses([raw.replace(";", ",")]) if "@" in a]


def actions_for_state(rule: dict, state) -> list:
    actions = rule.get("actions") or []
    specific = [a for a in actions if a.get("state") and state and a["state"].upper() == state.upper()]
    overridden = {a.get("type") for a in specific}
    general = [a for a in actions if not a.get("state") and a.get("type") not in overridden]
    return sorted(general + specific, key=lambda a: a.get("sequence", 0))


def plan_actions(rule: dict, fields: dict) -> list:
    out = []
    for act in actions_for_state(rule, fields.get("state")):
        params = act.get("params", {}) or {}
        kind = act.get("type")
        only_if = params.get("only_if_field")
        if only_if and not fields.get(only_if):
            out.append({"type": kind, "skipped": True, "reason": f"{only_if} is empty"})
        elif kind == "RENAME":
            name = safe_name(render(params.get("pattern", "{file_name}"), fields))
            out.append({"type": kind, "new_name": name if name.lower().endswith(".pdf") else name + ".pdf"})
        elif kind in ("MOVE", "MOVE_EMAIL"):
            out.append({"type": kind, "folder": render(params.get("folder", ""), fields)})
        elif kind == "CATEGORY":
            out.append({"type": kind, "categories": [render(c, fields) for c in params.get("categories", []) if c]})
        elif kind == "TAG":
            out.append({"type": kind, "categories": [render(t, fields) for t in params.get("tags", []) if t]})
        elif kind == "FORWARD":
            out.append({"type": kind, "to": _addresses(params.get("to"))})
    return out


def decide(rules: list, msg: dict, docs: list) -> dict:
    """
    Rules run in order; the first rule that matches a document claims it (like Rule Management).
    Returns {"winners": [...], "email": merged email actions, "files": per-attachment save plan}.
    """
    claimed, winners, checked = set(), [], []
    best = None
    # built once per email: reading fields from long PDF text is the slow part, and every rule needs the same result
    whole, per_doc = None, {}
    for rule in rules:
        if compatibility(rule)["level"] == "NOT_RUNNABLE":
            checked.append({"rule": rule.get("name"), "document": None, "score": None, "matched": False, "not_runnable": True})
            continue
        scope = (rule.get("scope") or "DOCUMENT").upper()
        if scope == "EMAIL":
            whole = whole or email_subject(msg, docs)
            subjects = [whole]
        else:
            flt = (rule.get("source_filter") or "ANY").upper()
            subjects = []
            for d in docs:
                if flt == "ANY" or (flt == "PDF") == (d["source"] != "EMAIL_BODY"):
                    if id(d) not in per_doc:
                        per_doc[id(d)] = document_subject(msg, d)
                    subjects.append(per_doc[id(d)])
        for subj in subjects:
            res = evaluate(rule, subj)
            if best is None or res["score"] > best["score"]:
                best = {"rule": rule.get("name"), "score": res["score"], "blocked_by": res["blocked_by"]}
            free = [d for d in subj["documents"] if id(d) not in claimed]
            checked.append({"rule": rule.get("name"), "document": ", ".join(d["file_name"] for d in subj["documents"]),
                            "score": res["score"], "threshold": rule.get("confidence_threshold"), "matched": bool(res["matched"]),
                            "blocked_by": res["blocked_by"], "already_claimed": bool(res["matched"] and not free)})
            if res["matched"] and free:
                claimed.update(id(d) for d in free)
                winners.append({"rule": rule, "score": res["score"], "fields": res["fields"], "documents": free})
    categories, forwards, move, files = [], [], None, []
    for w in winners:
        rule_name = w["rule"].get("name")
        for doc in w["documents"]:
            fields = {**w["fields"], "file_name": doc["file_name"]} if len(w["documents"]) > 1 else w["fields"]
            new_name, folder = None, None
            for a in plan_actions(w["rule"], fields):
                if a.get("skipped"):
                    continue
                if a["type"] == "RENAME":
                    new_name = a["new_name"]
                elif a["type"] == "MOVE":
                    folder = a["folder"]
                elif a["type"] == "MOVE_EMAIL":
                    move = move or {"folder": a["folder"], "rule": rule_name}
                elif a["type"] in ("CATEGORY", "TAG"):
                    categories += [c for c in a["categories"] if c not in categories]
                elif a["type"] == "FORWARD":
                    forwards += [t for t in a["to"] if t not in forwards]
            if (new_name or folder is not None) and doc["source"] != "EMAIL_BODY":
                files.append({"index": doc["index"], "file_name": doc["file_name"], "new_name": new_name or safe_name(doc["file_name"]),
                              "folder": folder or "", "rule": rule_name})
    return {"winners": [{"rule": w["rule"].get("name"), "version": w["rule"].get("version"), "score": w["score"],
                         "documents": [d["file_name"] for d in w["documents"]]} for w in winners],
            "categories": categories, "forward": forwards, "move": move, "files": files, "best": best, "checked": checked}
