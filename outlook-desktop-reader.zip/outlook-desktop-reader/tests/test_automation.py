"""Run:  python -m unittest discover -s tests   (no Outlook needed: uses the demo source)"""
import os
import sys
import tempfile
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from automation import Automation  # noqa: E402
from automation_engine import build_documents, checksum, compatibility, decide, extract_fields, filter_skip  # noqa: E402
from demo_source import DemoSource  # noqa: E402

RULE = {"id": 1, "name": "Hearing", "version": 2, "priority": 1, "scope": "EMAIL", "source_filter": "ANY", "document_types": [], "intents": [],
        "keywords": ["hearing"], "exclude_keywords": ["spam"], "keyword_mode": "any", "conditions": [], "inclusion_rules": [],
        "exclusion_rules": [], "use_vector": False, "confidence_threshold": 0.6,
        "actions": [{"sequence": 1, "type": "TAG", "params": {"tags": ["Court"]}},
                    {"sequence": 2, "type": "MOVE_EMAIL", "params": {"folder": "Hearings/{state}"}},
                    {"sequence": 3, "type": "FORWARD", "params": {"to": "team@firm.test"}}]}


def bundle(rules=None, client=1, filters=None, template=1):
    b = {"format": "rule-management-template", "format_version": 2, "client": {"id": client, "name": "Firm"},
         "exported_at": "2026-11-02T10:00:00", "exported_by": "a@b.c", "template": {"id": template, "name": f"T{template}"}, "filters": filters or {}, "rules": rules or [RULE]}
    b["checksum"] = checksum(b)
    return b


def msg(subject="Notice of Hearing", body="Case Number: 2026-CA-1\nHearing on November 16, 2026\nState of Florida"):
    return {"subject": subject, "sender": "Clerk", "sender_email": "clerk@court.gov", "body": body,
            "recipients": [{"address": "intake@firm.test"}]}


class Engine(unittest.TestCase):
    def test_fields(self):
        f = extract_fields(msg()["body"])
        self.assertEqual((f["case_number"], f["hearing_date"], f["state"]), ("2026-CA-1", "November 16, 2026", "FL"))

    def test_match_and_plan(self):
        m = msg()
        p = decide([RULE], m, build_documents(m, []))
        self.assertEqual(p["winners"][0]["rule"], "Hearing")
        self.assertEqual(p["categories"], ["Court"])
        self.assertEqual(p["move"]["folder"], "Hearings/FL")
        self.assertEqual(p["forward"], ["team@firm.test"])

    def test_excluded_keyword_blocks(self):
        m = msg(subject="hearing spam")
        self.assertEqual(decide([RULE], m, build_documents(m, []))["winners"], [])

    def test_fields_read_once_per_email(self):
        import automation_engine as e
        calls, real = [], e.extract_fields
        e.extract_fields = lambda t: calls.append(1) or real(t)
        try:
            m = msg()
            docs = build_documents(m, [{"index": 1, "file_name": "a.pdf", "text": "x", "page_count": 1}])
            rules = [{**RULE, "name": str(i), "keywords": ["none"], "scope": "DOCUMENT"} for i in range(10)]
            decide(rules, m, docs)
            self.assertEqual(len(calls), 2)  # two documents, whatever the number of rules
        finally:
            e.extract_fields = real

    def test_compatibility(self):
        self.assertEqual(compatibility(RULE)["level"], "FULL")
        self.assertEqual(compatibility({**RULE, "use_vector": True})["level"], "APPROXIMATE")
        self.assertEqual(compatibility({**RULE, "keywords": []})["level"], "NOT_RUNNABLE")

    def test_filters(self):
        self.assertIsNone(filter_skip({"folders": ["inbox"], "sender_whitelist": ["court.gov"]}, msg(), "Inbox/Court", ""))
        self.assertIn("folder", filter_skip({"folders": ["Archive"]}, msg(), "Inbox", ""))
        self.assertIn("mailbox", filter_skip({"mailbox_emails": ["x@y.z"]}, msg(), "Inbox", "a@b.c"))


class Worker(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.src = DemoSource()
        self.a = Automation(lambda: self.src, self.tmp.name)
        self.a.import_bundle(bundle())
        self.a.update_settings({"watches": [{"store": "store-1", "folder": "Inbox", "account": "x", "path": "Inbox"}]})

    def tearDown(self):
        self.tmp.cleanup()

    def arrive(self, subject="Notice of Hearing"):
        return self.src.simulate_new_email("store-1", subject, "clerk@court.gov")

    def test_old_mail_is_ignored_and_new_mail_once(self):
        self.assertEqual(self.a.poll_once(self.src), 0)
        self.arrive()
        self.assertEqual(self.a.poll_once(self.src), 1)
        self.assertEqual(self.a.poll_once(self.src), 0)

    def test_dry_run_changes_nothing(self):
        row = self.arrive()
        self.a.poll_once(self.src)
        self.assertEqual(row["categories"], "")
        self.assertIn(row, self.src.mail[("store-1", "Inbox")])
        self.assertEqual(self.a.log_rows()[0]["status"], "MATCHED")

    def test_live_runs_actions_forward_needs_permission(self):
        self.a.update_settings({"mode": "LIVE"})
        row = self.arrive()
        self.a.poll_once(self.src)
        self.assertEqual(row["categories"], "Court")
        self.assertNotIn(row, self.src.mail[("store-1", "Inbox")])
        results = {r["action"]: r for r in self.a.log_rows()[0]["detail"]["results"]}
        self.assertFalse(results["FORWARD"]["ok"])
        self.assertTrue(results["MOVE_EMAIL"]["ok"])

    def test_new_forward_returns_to_dry_run(self):
        self.a.update_settings({"mode": "LIVE"})
        self.assertFalse(self.a.import_bundle(bundle())["needs_review"])
        self.assertEqual(self.a.settings["mode"], "LIVE")
        r2 = {**RULE, "actions": [{"type": "FORWARD", "params": {"to": "other@x.test"}}]}
        self.assertTrue(self.a.import_bundle(bundle([r2]))["needs_review"])
        self.assertEqual(self.a.settings["mode"], "DRY_RUN")

    def test_same_template_updates_other_adds_other_client_refused(self):
        self.a.import_bundle(bundle([{**RULE, "name": "New"}]))
        self.assertEqual([t["rules"][0]["name"] for t in self.a.templates], ["New"])
        self.a.import_bundle(bundle(template=2))
        self.assertEqual(len(self.a.templates), 2)
        with self.assertRaises(ValueError):
            self.a.import_bundle(bundle(client=9, template=3))
        self.a.remove_template(1); self.a.remove_template(2)
        self.a.import_bundle(bundle(client=9, template=3))
        self.assertEqual(self.a.settings["mode"], "DRY_RUN")

    def test_first_template_that_applies_runs(self):
        self.a.remove_template(1)
        other = {**RULE, "name": "Other"}
        self.a.import_bundle(bundle([other], template=1, filters={"sender_whitelist": ["nobody.test"]}))
        self.a.import_bundle(bundle(template=2, filters={"subject_keywords": ["hearing"]}))
        self.arrive()
        self.a.poll_once(self.src)
        plan = self.a.log_rows()[0]["detail"]["plan"]
        self.assertEqual((plan["template"], plan["winners"][0]["rule"]), ("T2", "Hearing"))

    def test_no_template_applies_is_skipped(self):
        self.a.import_bundle(bundle(filters={"subject_keywords": ["zzz"]}))
        self.arrive()
        self.a.poll_once(self.src)
        row = self.a.log_rows()[0]
        self.assertEqual(row["status"], "SKIPPED")
        self.assertIn("T1", row["detail"]["reason"])

    def test_edited_file_is_refused(self):
        b = bundle()
        b["rules"][0] = {**RULE, "name": "changed"}
        with self.assertRaises(ValueError):
            self.a.import_bundle(b)

    def test_drop_folder_import(self):
        import json
        with open(os.path.join(self.a.drop_dir, "rules.json"), "w") as fh:
            json.dump(bundle([{**RULE, "name": "Dropped"}]), fh)
        self.a._drop_folder()
        self.assertEqual(self.a.templates[0]["rules"][0]["name"], "Dropped")
        self.assertEqual(os.listdir(self.a.drop_dir), [])

    def test_no_email_opened_just_for_its_id(self):
        calls = []
        real = self.src.internet_id
        self.src.internet_id = lambda *a: calls.append(a) or real(*a)
        self.arrive()
        self.assertEqual(self.a.poll_once(self.src), 1)
        self.assertEqual(calls, [])

    def test_attachment_read_once_and_saved(self):
        rule = {**RULE, "actions": [{"type": "RENAME", "params": {"pattern": "saved"}}]}
        self.a.import_bundle(bundle([rule]))
        self.a.update_settings({"mode": "LIVE", "output_dir": os.path.join(self.tmp.name, "out")})
        row = self.arrive()
        row["has_attachments"] = True
        reads = []
        real, message = self.src.attachment, self.src.message
        self.src.attachment = lambda *a: reads.append(a) or real(*a)
        self.src.message = lambda s, i: {**message(s, i), "attachments": [{"index": 1, "name": "Notice.pdf", "size": 10}]}
        self.a.poll_once(self.src)
        self.assertEqual(len(reads), 1)
        self.assertTrue(os.path.exists(os.path.join(self.tmp.name, "out", "saved.pdf")))

    def test_old_records_are_removed(self):
        self.a._log("LIVE", "", "", "", "old", "MATCHED", {})
        with self.a._db() as db:
            db.execute("UPDATE log SET at = '2000-01-01 10:00'")
        self.a._prune()
        self.assertEqual(self.a.log_rows(), [])

    def test_log_has_steps_and_text_file(self):
        self.arrive()
        self.a.poll_once(self.src)
        row = self.a.log_rows()[0]
        self.assertEqual((row["template"], row["rule"]), ("T1", "Hearing"))
        self.assertIsNotNone(row["duration_ms"])
        self.assertEqual([st["step"] for st in row["detail"]["steps"]], ["Template", "Rule", "Actions"])
        self.assertNotIn("checked", row["detail"]["plan"])
        with open(os.path.join(self.a.logs_dir, os.listdir(self.a.logs_dir)[0]), encoding="utf-8") as fh:
            text = fh.read()
        self.assertIn("MATCHED", text)
        self.assertIn("[OK] Rule: Hearing", text)

    def test_failed_action_is_partial(self):
        self.a.update_settings({"mode": "LIVE", "allow_forward": True})
        self.src.forward = lambda *a: (_ for _ in ()).throw(RuntimeError("blocked by Outlook"))
        self.arrive()
        self.a.poll_once(self.src)
        row = self.a.log_rows()[0]
        self.assertEqual(row["status"], "PARTIAL")
        self.assertIn("blocked by Outlook", str(row["detail"]["steps"]))
        self.assertEqual(self.a.log_page(status="PROBLEMS")["total"], 1)
        with self.a._db() as db:  # still counts as handled for the daily limit
            self.assertEqual(db.execute("SELECT status FROM processed WHERE status = 'MATCHED'").fetchone()[0], "MATCHED")

    def test_error_is_logged_with_traceback(self):
        self.src.message = lambda *a: (_ for _ in ()).throw(RuntimeError("email gone"))
        self.arrive()
        self.a.poll_once(self.src)
        row = self.a.log_rows()[0]
        self.assertEqual(row["status"], "ERROR")
        self.assertIn("email gone", row["detail"]["traceback"])

    def test_scanned_pdf_is_reported(self):
        self.src.message, real = (lambda s, i: {**real(s, i), "attachments": [{"index": 1, "name": "Scan.pdf", "size": 10}]}), self.src.message
        self.src.attachment = lambda *a: ("Scan.pdf", b"not a pdf")
        self.arrive()
        self.a.poll_once(self.src)
        self.assertIn("Scan.pdf: the PDF could not be read", str(self.a.log_rows()[0]["detail"]["steps"]))

    def test_log_search_and_events(self):
        self.arrive("Alpha hearing"); self.a.poll_once(self.src)
        self.arrive("Beta hearing"); self.a.poll_once(self.src)
        self.assertEqual(self.a.log_page(q="alpha")["items"][0]["subject"], "Alpha hearing")
        self.assertEqual(self.a.log_page(q="alpha")["total"], 1)
        self.assertEqual(self.a.log_page(status="SETTINGS_CHANGED")["total"], 1)
        self.assertEqual(self.a.log_page(status="IMPORTED")["total"], 1)
        with self.assertRaises(ValueError):
            self.a.import_bundle({"format": "wrong"})
        self.assertEqual(self.a.log_page(status="IMPORT_FAILED")["total"], 1)

    def test_csv_does_not_run_formulas(self):
        import app
        self.assertIn(b"'=cmd()", app.log_csv([{"subject": "=cmd()", "detail": {}}]))

    def test_sender_daily_limit(self):
        self.a.import_bundle(bundle(filters={"max_emails_per_sender_per_day": 1}))
        self.arrive(); self.a.poll_once(self.src)
        self.arrive("Hearing two"); self.a.poll_once(self.src)
        self.assertEqual(self.a.log_rows()[0]["status"], "SKIPPED")


if __name__ == "__main__":
    unittest.main()


# --------------------------------------------------------------------------- #
# Server engine, old emails, reports
# --------------------------------------------------------------------------- #
from automation import match_attachment, parse_when  # noqa: E402
from server_client import ServerUnavailable, build_eml  # noqa: E402


class FakeServer:
    """Stands in for the Rule Management server."""
    def __init__(self, status="MATCHED", down=False):
        self.status, self.down, self.sent, self.finished, self.items, self.runs = status, down, [], [], [], []

    def start_run(self, kind, mode, folders, date_from=None, date_to=None):
        self.runs.append({"kind": kind, "mode": mode})
        return {"id": len(self.runs)}

    def update_run(self, run_id, status=None, note=None):
        self.runs[run_id - 1]["status"] = status

    def process(self, eml, meta):
        if self.down:
            raise ServerUnavailable("cannot reach http://mac:8000")
        self.sent.append((eml, meta))
        plan = {"winners": [{"rule": "Hearing", "version": 3, "score": 0.9}], "categories": ["Court"], "forward": [],
                "move": None, "files": [{"file_name": "Notice.pdf", "new_name": "2026-CA-1.pdf", "folder": "Cases", "rule": "Hearing"}]}
        return {"id": len(self.sent), "status": self.status, "email_id": 500 + len(self.sent), "rule_names": "Hearing",
                "plan": plan if self.status == "MATCHED" else None, "documents": [], "error": None,
                "steps": [{"step": "Smart Analyzer", "ok": True, "text": "NOTICE / HearingScheduling"}]}

    def add_item(self, body):
        self.items.append(body)
        return {"id": 900 + len(self.items)}

    def finish_item(self, item_id, body):
        self.finished.append((item_id, body))


class ServerAndBackfill(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.src = DemoSource()
        self.a = Automation(lambda: self.src, self.tmp.name)
        self.a.import_bundle(bundle())
        self.a.update_settings({"watches": [{"store": "store-1", "folder": "Inbox", "account": "x", "path": "Inbox"}]})

    def tearDown(self):
        self.tmp.cleanup()

    def server(self, fake):
        self.a.update_settings({"server_url": "192.168.1.20:8000", "server_key": "odr_firm.secret", "engine": "SERVER"})
        self.a.client = lambda: fake

    def arrive(self, attach=True):
        row = self.src.simulate_new_email("store-1", "Notice of Hearing - 2026-CA-1", "clerk@court.gov")
        row["has_attachments"] = attach
        return row

    def wait_backfill(self):
        for _ in range(200):
            if not self.a.backfill.get("running"):
                return
            time.sleep(0.02)
        self.fail("old-email job did not finish")

    def test_helpers(self):
        self.assertEqual(parse_when("2026-11-01"), "2026-11-01 00:00")
        self.assertEqual(parse_when("2026-11-01", end=True), "2026-11-01 23:59")
        self.assertEqual(parse_when("2026-11-01T08:30"), "2026-11-01 08:30")
        with self.assertRaises(ValueError):
            parse_when("yesterday")
        atts = [{"index": 1, "name": "Notice of Hearing.PDF"}, {"index": 2, "name": "b.pdf"}]
        self.assertEqual(match_attachment("Notice_of_Hearing.PDF", atts), 1)
        self.assertEqual(match_attachment("b.pdf", atts), 2)
        self.assertIsNone(match_attachment("other.pdf", atts))

    def test_eml_has_body_and_attachment(self):
        import email
        from email import policy
        raw = build_eml({"subject": "Hi", "sender": "Clerk", "sender_email": "c@court.gov", "received": "2026-11-10 09:30",
                         "body": "Case 1", "recipients": [{"name": "I", "address": "i@firm.test", "type": "To"}]}, [("a.pdf", b"%PDF-1.4")])
        m = email.message_from_bytes(raw, policy=policy.default)
        self.assertEqual((m["Subject"], m["To"]), ("Hi", "I <i@firm.test>"))
        self.assertIn("Case 1", m.get_body(("plain",)).get_content())
        self.assertEqual([p.get_filename() for p in m.iter_attachments()], ["a.pdf"])

    def test_server_key_never_shown_and_engine_needs_it(self):
        with self.assertRaises(ValueError):
            self.a.update_settings({"engine": "SERVER"})
        self.a.update_settings({"server_url": "mac:8000", "server_key": "odr_firm.secret"})
        st = self.a.status()
        self.assertEqual(st["settings"]["server_key"], "")
        self.assertTrue(st["server"]["key_set"])
        self.assertNotIn("odr_firm.secret", str(self.a.log_rows(50)))

    def test_server_live_runs_the_returned_actions_and_reports_back(self):
        fake = FakeServer()
        self.server(fake)
        self.a.update_settings({"mode": "LIVE"})
        row = self.arrive()
        self.assertEqual(self.a.poll_once(self.src), 1)
        self.assertEqual(row["categories"], "Court")
        meta = fake.sent[0][1]
        self.assertEqual((meta["template_id"], meta["folder"], meta["mode"]), (1, "Inbox", "LIVE"))
        self.assertIn(b"Notice.pdf", fake.sent[0][0])
        item, report = fake.finished[0]
        self.assertEqual(report["status"], "DONE")
        self.assertEqual({r["action"] for r in report["action_results"]}, {"CATEGORY", "SAVE_ATTACHMENT"})
        saved = os.path.join(self.a.output_dir(), "Cases", "2026-CA-1.pdf")
        self.assertTrue(os.path.exists(saved))
        log = self.a.log_rows()[0]
        self.assertEqual((log["status"], log["engine"], log["server_item_id"]), ("MATCHED", "SERVER", 1))
        self.assertTrue(any(s["step"].startswith("Server ·") for s in log["detail"]["steps"]))
        self.assertEqual(fake.runs[0]["kind"], "LIVE_MONITOR")

    def test_server_dry_run_changes_nothing(self):
        fake = FakeServer()
        self.server(fake)
        row = self.arrive()
        self.a.poll_once(self.src)
        self.assertEqual(row["categories"], "")
        self.assertEqual(fake.finished[0][1]["status"], "MATCHED")

    def test_server_down_email_waits_and_is_done_later(self):
        fake = FakeServer(down=True)
        self.server(fake)
        self.arrive()
        self.assertEqual(self.a.poll_once(self.src), 0)
        self.assertEqual(self.a.log_rows()[0]["status"], "SERVER_UNREACHABLE")
        self.assertFalse(self.a.status()["server"]["ok"])
        fake.down = False
        self.assertEqual(self.a.poll_once(self.src), 1)
        self.assertEqual(len(fake.sent), 1)
        self.assertIn("CONNECTION_RESTORED", [r["status"] for r in self.a.log_rows()[:3]])

    def test_no_template_is_reported_to_server_as_skipped(self):
        fake = FakeServer()
        self.a.import_bundle(bundle(filters={"sender_whitelist": ["only@x.test"]}))
        self.server(fake)
        self.arrive()
        self.a.poll_once(self.src)
        self.assertEqual(fake.sent, [])
        self.assertEqual(fake.items[0]["status"], "SKIPPED")

    def test_backfill_range_once_then_again(self):
        rows = [r for r in self.src.mail[("store-1", "Inbox")] if "2026-10-26 00:00" <= r["received"] <= "2026-10-27 23:59"]
        self.assertTrue(rows)
        self.a.start_backfill({"date_from": "2026-10-26", "date_to": "2026-10-27", "mode": "DRY_RUN"})
        self.wait_backfill()
        b = self.a.backfill
        self.assertEqual((b["status"], b["found"], b["done"]), ("COMPLETED", len(rows), len(rows)))
        run = self.a.runs()[0]
        self.assertEqual((run["kind"], run["status"], run["totals"]["total"]), ("BACKFILL", "COMPLETED", len(rows)))
        emails = [r for r in self.a.log_rows(500, run_id=run["id"]) if not r["status"].startswith("BACKFILL")]
        self.assertEqual(len(emails), len(rows))
        self.a.start_backfill({"date_from": "2026-10-26", "date_to": "2026-10-27"})
        self.wait_backfill()
        self.assertEqual((self.a.backfill["done"], self.a.backfill["already"]), (0, len(rows)))
        self.a.start_backfill({"date_from": "2026-10-26", "date_to": "2026-10-27", "again": True})
        self.wait_backfill()
        self.assertEqual(self.a.backfill["done"], len(rows))

    def test_backfill_checks(self):
        with self.assertRaises(ValueError):
            self.a.start_backfill({"date_from": "2026-10-28", "date_to": "2026-10-01"})
        with self.assertRaises(ValueError):
            self.a.start_backfill({"date_from": "2026-10-01", "mode": "OFF"})

    def test_backfill_with_server_down_stops_and_keeps_emails(self):
        fake = FakeServer(down=True)
        self.server(fake)
        self.a.start_backfill({"date_from": "2026-10-26", "date_to": "2026-10-27"})
        self.wait_backfill()
        self.assertEqual(self.a.backfill["status"], "FAILED")
        self.assertEqual(self.a.runs()[0]["status"], "FAILED")
        fake.down = False
        self.a.start_backfill({"date_from": "2026-10-26", "date_to": "2026-10-27"})
        self.wait_backfill()
        self.assertEqual(self.a.backfill["already"], 0)  # nothing was marked done while the server was down
