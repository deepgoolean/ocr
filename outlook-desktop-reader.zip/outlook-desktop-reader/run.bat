@echo off
rem Outlook Desktop Reader - first run creates .venv and installs pywin32, then starts the viewer.
rem Usage:  run.bat            (viewer)
rem         run.bat export     (export all emails to .\export)
setlocal
cd /d "%~dp0"

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (where python >nul 2>nul && set "PY=python")
if not defined PY (
  echo Python 3.8 or newer is required: https://www.python.org/downloads/windows/
  echo During install tick "Add python.exe to PATH". Or use OutlookReader.exe (see README).
  pause & exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  %PY% -m venv .venv || (echo Could not create .venv & pause & exit /b 1)
)

".venv\Scripts\python.exe" -c "import win32com.client" >nul 2>nul
if errorlevel 1 (
  echo Installing pywin32...
  if exist "wheels\" (
    ".venv\Scripts\python.exe" -m pip install --no-index --find-links wheels -r requirements.txt
  ) else (
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  )
  if errorlevel 1 (echo pywin32 install failed - check internet / proxy & pause & exit /b 1)
)

".venv\Scripts\python.exe" app.py %*
if errorlevel 1 pause
