"""
Fake Outlook data with the same interface as OutlookSource.
Used by  python app.py --demo  to try the screens on any machine (macOS / Linux / no Outlook).
"""
from __future__ import annotations

import random
from datetime import datetime, timedelta

ACCOUNTS = [
    {"id": "store-1", "name": "intake@lawfirm-demo.test", "email": "intake@lawfirm-demo.test",
     "type": "Exchange / Microsoft 365", "file_path": None, "is_default": True},
    {"id": "store-2", "name": "paralegal@gmail-demo.test", "email": "paralegal@gmail-demo.test",
     "type": "IMAP", "file_path": None, "is_default": False},
    {"id": "store-3", "name": "Archive 2025", "email": None, "type": "Data file",
     "file_path": r"C:\Users\demo\Documents\Outlook Files\Archive 2025.pst", "is_default": False},
]
TREE = {
    None: ["Inbox", "Sent Items", "Deleted Items", "Calendar"],
    "Inbox": ["Court Notices", "Clients"],
    "Court Notices": ["2026"],
}
SUBJECTS = ["SERVICE OF COURT DOCUMENT - Case 2026-CA-00{n}", "Notice of Hearing - 2026-CA-00{n}",
            "NEF: Order entered - 2025-CA-0{n}", "Re: documents for case {n}", "Invoice {n}"]
SENDERS = [("Clerk of Court e-Filing", "efiling@courts-demo.test"), ("Rosa Delgado", "ja@courts-demo.test"),
           ("Amara Bello", "filings@osei-demo.test"), ("Client Support", "support@vendor-demo.test")]


class DemoSource:
    mode = "demo"

    def __init__(self):
        rnd = random.Random(7)
        self.mail: dict[tuple[str, str], list[dict]] = {}
        now = datetime(2026, 10, 28, 9, 0)
        for acc in ACCOUNTS:
            for folder in self._all_folders():
                rows = []
                for i in range(rnd.randint(0, 140) if folder != "Calendar" else 0):
                    name, email = rnd.choice(SENDERS)
                    n = rnd.randint(1000, 9999)
                    rows.append({
                        "id": f"{acc['id']}|{folder}|{i}", "subject": rnd.choice(SUBJECTS).format(n=n), "sender": name,
                        "sender_email": email, "received": (now - timedelta(hours=i * 7 + rnd.randint(0, 6))).strftime("%Y-%m-%d %H:%M"),
                        "size": rnd.randint(8_000, 900_000), "unread": rnd.random() < 0.3, "has_attachments": rnd.random() < 0.5,
                        "categories": rnd.choice(["", "", "Court", "Urgent"]), "type": "IPM.Note",
                    })
                self.mail[(acc["id"], folder)] = rows

    @staticmethod
    def _all_folders() -> list[str]:
        out, stack = [], list(TREE[None])
        while stack:
            f = stack.pop()
            out.append(f)
            stack += TREE.get(f, [])
        return out

    def accounts(self):
        return ACCOUNTS

    def folders(self, store_id, parent_id=None):
        result = []
        for name in TREE.get(parent_id, []):
            rows = self.mail.get((store_id, name), [])
            result.append({"id": name, "name": name, "path": f"\\\\{store_id}\\{name}", "total": len(rows),
                           "unread": sum(r["unread"] for r in rows), "has_children": name in TREE,
                           "kind": "Calendar" if name == "Calendar" else "Mail"})
        return result

    def messages(self, store_id, folder_id, offset=0, limit=50, q="", sender="", unread=False, since=""):
        rows = [{**r, "internet_id": f"<{r['id']}@demo>"} for r in self.mail.get((store_id, folder_id), [])]
        if q:
            rows = [r for r in rows if q.lower() in r["subject"].lower()]
        if sender:
            rows = [r for r in rows if sender.lower() in (r["sender"] + r["sender_email"]).lower()]
        if unread:
            rows = [r for r in rows if r["unread"]]
        if since:
            rows = [r for r in rows if r["received"] >= since]
        return {"total": len(rows), "offset": offset, "items": rows[offset:offset + limit]}

    def _row(self, entry_id):
        store, folder, _ = entry_id.split("|")
        return next(r for r in self.mail[(store, folder)] if r["id"] == entry_id)

    def message(self, store_id, entry_id):
        r = self._row(entry_id)
        body = (f"Case Number: {r['subject'].split()[-1]}\nCourt: Circuit Court, Palm Grove County (demo)\n"
                "Hearing date: November 16, 2026 at 9:30 AM\n\nThis is demo data.")
        return {**r, "recipients": [{"name": "Intake", "address": "intake@lawfirm-demo.test", "type": "To"}],
                "sent": r["received"], "importance": "Normal", "conversation": r["subject"],
                "body": body, "html": f"<p><b>{r['subject']}</b></p><pre>{body}</pre>",
                "headers": f"From: {r['sender']} <{r['sender_email']}>\nSubject: {r['subject']}\nX-Demo: yes",
                "attachments": [{"index": 1, "name": "Notice.pdf", "size": 102400}] if r["has_attachments"] else []}

    # ---- used by automation -------------------------------------------------
    def inbox(self, store_id):
        return self.folder_info(store_id, "Inbox")

    def folder_info(self, store_id, folder_id):
        rows = self.mail.get((store_id, folder_id), [])
        return {"id": folder_id, "name": folder_id, "path": f"\\\\{store_id}\\{folder_id}", "total": len(rows),
                "unread": sum(r["unread"] for r in rows), "has_children": folder_id in TREE, "kind": "Mail"}

    def internet_id(self, store_id, entry_id):
        return "<" + entry_id + "@demo>"

    def add_categories(self, store_id, entry_id, categories):
        r = self._row(entry_id)
        current = [c.strip() for c in r["categories"].split(",") if c.strip()]
        r["categories"] = ", ".join(current + [c for c in categories if c not in current])
        return r["categories"]

    def move(self, store_id, entry_id, path):
        r = self._row(entry_id)
        _, folder, _ = entry_id.split("|")
        self.mail[(store_id, folder)].remove(r)
        name = path.replace("\\", "/").strip("/").replace("/", " - ") or "Moved"
        TREE[None].count(name) or TREE[None].append(name)
        r["id"] = f"{store_id}|{name}|{entry_id.split('|')[2]}"
        self.mail.setdefault((store_id, name), []).insert(0, r)
        return name

    def forward(self, store_id, entry_id, to):
        return "demo: not really sent to " + ", ".join(to)

    def simulate_new_email(self, store_id, subject, sender_email, body=""):
        """Demo only: a new email arrives in the Inbox."""
        rows = self.mail.setdefault((store_id, "Inbox"), [])
        self.counter = getattr(self, "counter", 0) + 1
        row = {"id": f"{store_id}|Inbox|new{self.counter}", "subject": subject, "sender": sender_email, "sender_email": sender_email,
               "received": datetime.now().strftime("%Y-%m-%d %H:%M"), "size": 20000, "unread": True,
               "has_attachments": False, "categories": "", "type": "IPM.Note"}
        rows.insert(0, row)
        return row

    def attachment(self, store_id, entry_id, index):
        return "Notice.txt", b"Demo attachment content\n"

    def msg_file(self, store_id, entry_id):
        return "message.txt", b"Demo: .msg export works only with real Outlook.\n"
