"""
Outlook Desktop Reader - browse every account / folder / email of Classic Outlook for Windows.

    python app.py                      start the viewer  -> http://127.0.0.1:8765
    python app.py --demo               same screens with fake data (any OS, no Outlook needed)
    python app.py export --out export  write all accounts / folders / emails to CSV + JSON

Read-only: nothing is changed, moved or sent in Outlook. The viewer listens on 127.0.0.1 only.
Standalone tool: not connected to any other application.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, quote, urlparse

VERSION = "1.0.0"
BASE_DIR = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))  # also inside the .exe
SOURCE = None  # OutlookSource or DemoSource (one COM connection, used by the single server thread)


def error_text(exc: Exception) -> str:
    from outlook_source import com_error_text

    return com_error_text(exc) if type(exc).__name__ == "com_error" else f"{type(exc).__name__}: {exc}"


class Handler(BaseHTTPRequestHandler):
    server_version = "OutlookReader/" + VERSION

    def log_message(self, fmt, *args):  # quieter console: only errors are printed
        pass

    # ---- helpers -------------------------------------------------------------
    def send_json(self, data, status=200):
        body = json.dumps(data, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_file(self, name: str, data: bytes, content_type="application/octet-stream", inline=False):
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        disposition = "inline" if inline else "attachment"
        self.send_header("Content-Disposition", f"{disposition}; filename*=UTF-8''{quote(name)}")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    # ---- routes --------------------------------------------------------------
    def do_GET(self):
        url = urlparse(self.path)
        p = {k: v[0] for k, v in parse_qs(url.query).items()}
        try:
            if url.path in ("/", "/index.html"):
                with open(os.path.join(BASE_DIR, "static", "index.html"), "rb") as fh:
                    return self.send_file("index.html", fh.read(), "text/html; charset=utf-8", inline=True)
            if url.path == "/api/info":
                return self.send_json({"mode": SOURCE.mode, "version": VERSION})
            if url.path == "/api/accounts":
                return self.send_json(SOURCE.accounts())
            if url.path == "/api/folders":
                return self.send_json(SOURCE.folders(p["store"], p.get("parent") or None))
            if url.path == "/api/messages":
                return self.send_json(SOURCE.messages(
                    p["store"], p["folder"], offset=int(p.get("offset", 0)), limit=min(int(p.get("limit", 50)), 500),
                    q=p.get("q", ""), sender=p.get("sender", ""), unread=p.get("unread") == "1", since=p.get("since", "")))
            if url.path == "/api/message":
                return self.send_json(SOURCE.message(p["store"], p["id"]))
            if url.path == "/api/attachment":
                name, data = SOURCE.attachment(p["store"], p["id"], int(p["index"]))
                return self.send_file(name, data)
            if url.path == "/api/msg":
                name, data = SOURCE.msg_file(p["store"], p["id"])
                return self.send_file(name, data)
            if url.path == "/api/export.csv":
                rows = SOURCE.messages(p["store"], p["folder"], limit=int(p.get("limit", 5000)), q=p.get("q", ""),
                                       sender=p.get("sender", ""), unread=p.get("unread") == "1", since=p.get("since", ""))["items"]
                return self.send_file("emails.csv", to_csv(rows), "text/csv; charset=utf-8")
            self.send_json({"error": "not found"}, 404)
        except KeyError as exc:
            self.send_json({"error": f"missing parameter {exc}"}, 400)
        except Exception as exc:
            traceback.print_exc()
            self.send_json({"error": error_text(exc)}, 500)


FIELDS = ["received", "sender", "sender_email", "subject", "unread", "has_attachments", "size", "categories", "type"]


def to_csv(rows: list[dict], extra: list[str] | None = None) -> bytes:
    import io

    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=(extra or []) + FIELDS, extrasaction="ignore")
    w.writeheader()
    w.writerows(rows)
    return ("﻿" + buf.getvalue()).encode("utf-8")  # BOM: Excel opens UTF-8 correctly


# --------------------------------------------------------------------------- #
# export: all accounts -> <out>/<account>/emails.csv + folders.json
# --------------------------------------------------------------------------- #
def export_all(out: str, account_filter: str = "", max_per_folder: int = 0, with_body: bool = False) -> None:
    os.makedirs(out, exist_ok=True)
    for acc in SOURCE.accounts():
        label = acc["email"] or acc["name"]
        if account_filter and account_filter.lower() not in label.lower():
            continue
        folder_dir = os.path.join(out, "".join(c if c.isalnum() or c in "@._- " else "_" for c in label))
        os.makedirs(folder_dir, exist_ok=True)
        print(f"Account: {label}")
        folders, rows = [], []
        stack = [(None, "")]
        while stack:
            parent, path = stack.pop()
            try:
                children = SOURCE.folders(acc["id"], parent)
            except Exception as exc:
                print(f"  ! cannot read folders under {path or '/'}: {error_text(exc)}")
                continue
            for f in children:
                fpath = f"{path}/{f['name']}"
                folders.append({**f, "path": fpath})
                if f["has_children"]:
                    stack.append((f["id"], fpath))
                if f["kind"] != "Mail" or not f["total"]:
                    continue
                limit = max_per_folder or f["total"]
                try:
                    items = SOURCE.messages(acc["id"], f["id"], limit=limit)["items"]
                except Exception as exc:
                    print(f"  ! {fpath}: {error_text(exc)}")
                    continue
                for it in items:
                    it["folder"] = fpath
                    if with_body:
                        try:
                            it["body"] = SOURCE.message(acc["id"], it["id"])["body"]
                        except Exception:
                            it["body"] = ""
                rows += items
                print(f"  {fpath}: {len(items)} email(s)")
        with open(os.path.join(folder_dir, "folders.json"), "w", encoding="utf-8") as fh:
            json.dump({"account": acc, "folders": folders}, fh, indent=2, default=str)
        extra = ["folder"] + (["body"] if with_body else [])
        with open(os.path.join(folder_dir, "emails.csv"), "wb") as fh:
            fh.write(to_csv(rows, extra))
        if with_body:
            with open(os.path.join(folder_dir, "emails.json"), "w", encoding="utf-8") as fh:
                json.dump(rows, fh, indent=2, default=str)
        print(f"  -> {len(rows)} email(s), {len(folders)} folder(s) in {folder_dir}")


def main() -> None:
    global SOURCE
    ap = argparse.ArgumentParser(description="Outlook Desktop Reader (read-only)")
    ap.add_argument("--demo", action="store_true", help="fake data, no Outlook needed")
    sub = ap.add_subparsers(dest="cmd")
    serve = sub.add_parser("serve", help="start the viewer (default)")
    for target in (ap, serve):
        target.add_argument("--port", type=int, default=8765)
        target.add_argument("--no-browser", action="store_true")
    exp = sub.add_parser("export", help="export all emails to CSV / JSON")
    exp.add_argument("--out", default="export")
    exp.add_argument("--account", default="", help="only accounts whose name / e-mail contains this text")
    exp.add_argument("--max", type=int, default=0, help="max emails per folder (0 = all)")
    exp.add_argument("--with-body", action="store_true", help="include the plain-text body (slower)")
    args, _ = ap.parse_known_args()
    if "--demo" in sys.argv:
        args.demo = True

    if args.demo:
        from demo_source import DemoSource
        SOURCE = DemoSource()
    else:
        if sys.platform != "win32":
            sys.exit("Outlook access works only on Windows with Classic Outlook. Try:  python app.py --demo")
        from outlook_source import OutlookSource
        try:
            SOURCE = OutlookSource()
        except SystemExit:
            raise
        except Exception as exc:
            sys.exit(f"Cannot open Outlook: {error_text(exc)}\n"
                     "Check: Classic Outlook is installed and signed in, and this window is NOT 'Run as administrator'.")

    if args.cmd == "export":
        export_all(args.out, args.account, args.max, args.with_body)
        return

    httpd = HTTPServer(("127.0.0.1", args.port), Handler)  # single thread: required for Outlook COM
    url = f"http://127.0.0.1:{args.port}"
    print(f"Outlook Desktop Reader {VERSION} ({SOURCE.mode}) on {url}   - press Ctrl+C to stop")
    if not args.no_browser:
        webbrowser.open(url)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("Stopped.")


if __name__ == "__main__":
    main()
