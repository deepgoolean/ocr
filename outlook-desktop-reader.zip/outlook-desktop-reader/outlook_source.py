"""
Read Classic Outlook for Windows through COM (pywin32). READ-ONLY: nothing is changed in Outlook.

Every "account" shown is an Outlook store (mailbox of an account, shared mailbox, or .pst/.ost file),
matched to its Outlook account (name, e-mail, type) when it has one.

Message lists use Outlook's Table object (fast: only the needed columns are read).
"""
from __future__ import annotations

import os
import tempfile

ACCOUNT_TYPES = {0: "Exchange / Microsoft 365", 1: "IMAP", 2: "POP3", 3: "HTTP", 4: "Exchange ActiveSync", 5: "Other"}
ITEM_TYPES = {0: "Mail", 1: "Calendar", 2: "Contacts", 3: "Tasks", 4: "Journal", 5: "Notes"}
RECIPIENT_TYPES = {1: "To", 2: "Cc", 3: "Bcc"}

PR_SENDER_EMAIL = "http://schemas.microsoft.com/mapi/proptag/0x0C1F001F"
PR_HEADERS = "http://schemas.microsoft.com/mapi/proptag/0x007D001F"
HAS_ATTACH = "urn:schemas:httpmail:hasattachment"
OL_MSG_UNICODE = 9


def dt(value) -> str | None:
    """COM date -> 'YYYY-MM-DD HH:MM' (Outlook uses year 4501 for 'no date')."""
    try:
        if value is None or value.year >= 4500:
            return None
        return value.strftime("%Y-%m-%d %H:%M")
    except Exception:
        return None


def safe(obj, name, default=None):
    """Read a COM property; some item types / stores do not have every property."""
    try:
        return getattr(obj, name)
    except Exception:
        return default


def dasl_text(value: str) -> str:
    return value.replace("'", "''").replace("%", "")


class OutlookSource:
    mode = "outlook"

    def __init__(self):
        try:
            import pythoncom
            import win32com.client
        except ImportError:
            raise SystemExit("pywin32 is missing. Run:  pip install pywin32   (Windows only)")
        pythoncom.CoInitialize()
        # dynamic dispatch: no generated cache files needed (avoids the common gen_py errors)
        self.app = win32com.client.dynamic.Dispatch("Outlook.Application")
        self.ns = self.app.GetNamespace("MAPI")

    # ---- accounts -------------------------------------------------------------
    def accounts(self) -> list[dict]:
        by_store = {}
        for i in range(1, self.ns.Accounts.Count + 1):
            a = self.ns.Accounts.Item(i)
            store = safe(a, "DeliveryStore")
            if store is not None:
                by_store[safe(store, "StoreID")] = a
        default_store = safe(safe(self.ns, "DefaultStore"), "StoreID")
        result = []
        for i in range(1, self.ns.Stores.Count + 1):
            s = self.ns.Stores.Item(i)
            sid = s.StoreID
            a = by_store.get(sid)
            is_file = bool(safe(s, "IsDataFileStore", False))
            kind = ACCOUNT_TYPES.get(safe(a, "AccountType"), "Account") if a else ("Data file" if is_file else "Shared / other")
            result.append({
                "id": sid, "name": s.DisplayName, "email": safe(a, "SmtpAddress") if a else None,
                "type": kind, "file_path": safe(s, "FilePath") or None, "is_default": sid == default_store,
            })
        result.sort(key=lambda x: (not x["is_default"], x["email"] is None, x["name"].lower()))
        return result

    # ---- folders -------------------------------------------------------------
    def _folder_info(self, f) -> dict:
        kind = safe(f, "DefaultItemType", 0)
        return {
            "id": f.EntryID, "name": f.Name, "path": safe(f, "FolderPath", f.Name),
            "total": safe(safe(f, "Items"), "Count", 0), "unread": safe(f, "UnReadItemCount", 0),
            "has_children": safe(safe(f, "Folders"), "Count", 0) > 0, "kind": ITEM_TYPES.get(kind, "Other"),
        }

    def folders(self, store_id: str, parent_id: str | None = None) -> list[dict]:
        if parent_id:
            parent = self.ns.GetFolderFromID(parent_id, store_id)
        else:
            parent = self.ns.GetStoreFromID(store_id).GetRootFolder()
        items = []
        for i in range(1, parent.Folders.Count + 1):
            try:
                items.append(self._folder_info(parent.Folders.Item(i)))
            except Exception:
                continue  # folders without access
        return items

    # ---- messages ------------------------------------------------------------
    def messages(self, store_id: str, folder_id: str, offset: int = 0, limit: int = 50, q: str = "",
                 sender: str = "", unread: bool = False, since: str = "") -> dict:
        folder = self.ns.GetFolderFromID(folder_id, store_id)
        parts = []
        if q:
            parts.append(f"\"urn:schemas:httpmail:subject\" LIKE '%{dasl_text(q)}%'")
        if sender:
            s = dasl_text(sender)
            parts.append(f"(\"urn:schemas:httpmail:fromname\" LIKE '%{s}%' OR \"urn:schemas:httpmail:fromemail\" LIKE '%{s}%')")
        if unread:
            parts.append("\"urn:schemas:httpmail:read\" = 0")
        if since:  # YYYY-MM-DD
            y, m, d = since.split("-")
            parts.append(f"\"urn:schemas:httpmail:datereceived\" >= '{m}/{d}/{y}'")
        table = folder.GetTable("@SQL=" + " AND ".join(parts) if parts else "", 0)
        cols = table.Columns
        cols.RemoveAll()
        names = ["EntryID", "Subject", "SenderName", "ReceivedTime", "Size", "UnRead", "Categories", "MessageClass"]
        for c in names:
            cols.Add(c)
        extra = []
        for c in (HAS_ATTACH, PR_SENDER_EMAIL):
            try:
                cols.Add(c)
                extra.append(c)
            except Exception:
                pass
        try:
            table.Sort("[ReceivedTime]", True)
        except Exception:
            pass
        total = table.GetRowCount()
        for _ in range(offset):
            if table.EndOfTable:
                break
            table.GetNextRow()
        items = []
        while not table.EndOfTable and len(items) < limit:
            v = dict(zip(names + extra, table.GetNextRow().GetValues()))
            items.append({
                "id": v["EntryID"], "subject": v["Subject"] or "", "sender": v["SenderName"] or "",
                "sender_email": v.get(PR_SENDER_EMAIL) or "", "received": dt(v["ReceivedTime"]),
                "size": v["Size"], "unread": bool(v["UnRead"]), "has_attachments": bool(v.get(HAS_ATTACH)),
                "categories": v["Categories"] or "", "type": v["MessageClass"] or "",
            })
        return {"total": total, "offset": offset, "items": items}

    # ---- one message ---------------------------------------------------------
    def _item(self, store_id: str, entry_id: str):
        return self.ns.GetItemFromID(entry_id, store_id)

    def _smtp(self, entry) -> str | None:
        try:
            user = entry.GetExchangeUser()
            return user.PrimarySmtpAddress if user else None
        except Exception:
            return None

    def message(self, store_id: str, entry_id: str) -> dict:
        it = self._item(store_id, entry_id)
        sender_email = safe(it, "SenderEmailAddress")
        if safe(it, "SenderEmailType") == "EX":
            sender_email = self._smtp(safe(it, "Sender")) or sender_email
        recipients = []
        recips = safe(it, "Recipients")
        for i in range(1, (safe(recips, "Count", 0) or 0) + 1):
            r = recips.Item(i)
            address = safe(r, "Address")
            if address and address.startswith("/o="):
                address = self._smtp(safe(r, "AddressEntry")) or address
            recipients.append({"name": safe(r, "Name"), "address": address, "type": RECIPIENT_TYPES.get(safe(r, "Type"), "To")})
        attachments = []
        atts = safe(it, "Attachments")
        for i in range(1, (safe(atts, "Count", 0) or 0) + 1):
            a = atts.Item(i)
            attachments.append({"index": i, "name": safe(a, "FileName") or safe(a, "DisplayName") or f"attachment-{i}",
                                "size": safe(a, "Size")})
        headers = None
        try:
            headers = it.PropertyAccessor.GetProperty(PR_HEADERS)
        except Exception:
            pass
        return {
            "id": entry_id, "subject": safe(it, "Subject", ""), "sender": safe(it, "SenderName"),
            "sender_email": sender_email, "recipients": recipients, "received": dt(safe(it, "ReceivedTime")),
            "sent": dt(safe(it, "SentOn")), "importance": {0: "Low", 1: "Normal", 2: "High"}.get(safe(it, "Importance"), ""),
            "categories": safe(it, "Categories", ""), "unread": safe(it, "UnRead"), "size": safe(it, "Size"),
            "conversation": safe(it, "ConversationTopic"), "type": safe(it, "MessageClass"),
            "body": safe(it, "Body", "") or "", "html": safe(it, "HTMLBody", "") or "",
            "headers": headers, "attachments": attachments,
        }

    def attachment(self, store_id: str, entry_id: str, index: int) -> tuple[str, bytes]:
        a = self._item(store_id, entry_id).Attachments.Item(index)
        name = safe(a, "FileName") or f"attachment-{index}"
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "file")
            a.SaveAsFile(path)
            with open(path, "rb") as fh:
                return name, fh.read()

    def msg_file(self, store_id: str, entry_id: str) -> tuple[str, bytes]:
        it = self._item(store_id, entry_id)
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "message.msg")
            it.SaveAs(path, OL_MSG_UNICODE)
            with open(path, "rb") as fh:
                return (safe(it, "Subject") or "message")[:80] + ".msg", fh.read()


def com_error_text(exc: Exception) -> str:
    """Readable text for pywintypes.com_error."""
    try:
        info = exc.excepinfo  # type: ignore[attr-defined]
        if info and info[2]:
            return str(info[2])
        return str(exc.args[1])  # type: ignore[attr-defined]
    except Exception:
        return f"{type(exc).__name__}: {exc}"
