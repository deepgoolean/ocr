@echo off
rem Build dist\OutlookReader.exe - ONE file that runs on any Windows PC with Classic Outlook,
rem with NO Python and NO other installation. Run this once on any Windows PC that has Python 3.8+.
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv 2>nul || python -m venv .venv || (echo Python 3.8+ not found & pause & exit /b 1)
)
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
".venv\Scripts\python.exe" -m pip install -r requirements.txt pyinstaller || (pause & exit /b 1)
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --name OutlookReader ^
  --add-data "static;static" --hidden-import win32timezone --hidden-import win32com.client app.py || (pause & exit /b 1)
echo.
echo Done: dist\OutlookReader.exe   (copy only this file to the other PC and double-click it)
pause
