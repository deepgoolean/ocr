"""
Automation: imported templates (each with its rules) + a background worker that checks new emails in the watched folders.

Modes  OFF      nothing runs
       DRY_RUN  rules are checked and logged, Outlook and disk are not touched (default after import)
       LIVE     actions run: categories, save renamed PDFs to disk, forward (only if allowed), move email

Engines  LOCAL    rules run on this PC (text patterns, no Smart Analyzer); works without a network
         SERVER   each email (body + PDFs) is sent to the Rule Management server in the LAN: it runs the
                  Smart Analyzer (model -> other models -> regex) and the template's rules, and sends back
                  the actions; this PC carries them out in Outlook and reports the result back.
Runs     every monitoring day (LIVE_MONITOR) and every "process old emails" job (BACKFILL) is one run:
         a report with counts, kept here and (SERVER engine) in the web panel too.

An email runs under the first imported template whose "applies to" filters it passes, as in Rule Management.
Only emails received after a folder was added (or automation was switched on) are processed, and each
email only once: it is recorded BEFORE its actions run, so a crash can never forward it twice.
All data stays in automation_data/ next to the program. Every step is logged: the log table (Activity screen)
and one text file per day in automation_data/logs/. Email bodies and PDF text are never logged.
"""
from __future__ import annotations

import io
import json
import os
import shutil
import sqlite3
import sys
import threading
import time
import traceback
from datetime import datetime, timedelta

from server_client import ServerClient, ServerError, ServerUnavailable, build_eml
from automation_engine import body_filter_skip, compatibility, decide, build_documents, filter_skip, folder_parts, \
    forward_recipients, safe_name, validate_bundle

MODES = ("OFF", "DRY_RUN", "LIVE")
MAX_PER_POLL = 50
MAX_PDF_BYTES = 25 * 1024 * 1024
RETENTION_DAYS = 90  # activity and "already processed" records older than this are removed
HOME = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(os.path.abspath(__file__))
PROBLEMS = ("ERROR", "PARTIAL", "IMPORT_FAILED", "CONNECTION_LOST", "SERVER_UNREACHABLE", "NEEDS_REVIEW", "ACTION_FAILED")
DEFAULTS = {"mode": "DRY_RUN", "allow_forward": False, "poll_seconds": 30, "output_dir": "", "watches": [],
            "engine": "LOCAL", "server_url": "", "server_key": ""}
ENGINES = ("LOCAL", "SERVER")
VERSION = "1.2.0"
BACKFILL_PAGE = 200
BACKFILL_MAX = 5000   # emails per job


def parse_when(value: str, end: bool = False) -> str:
    """'2026-11-01' or '2026-11-01 08:30' (also with T) -> 'YYYY-MM-DD HH:MM' as Outlook rows use it."""
    value = (value or "").strip().replace("T", " ")[:16]
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            d = datetime.strptime(value, fmt)
            if fmt == "%Y-%m-%d" and end:
                return d.strftime("%Y-%m-%d") + " 23:59"
            return d.strftime("%Y-%m-%d %H:%M")
        except ValueError:
            continue
    raise ValueError(f"'{value}' is not a date (use YYYY-MM-DD or YYYY-MM-DD HH:MM)")


def _norm_name(name: str) -> str:
    return "".join(ch for ch in (name or "").lower() if ch.isalnum())


def match_attachment(server_name: str, attachments: list):
    """Index of the Outlook attachment the server's document came from (the server cleans file names)."""
    for test in (lambda a: a["name"] == server_name, lambda a: a["name"].lower() == server_name.lower(),
                 lambda a: _norm_name(a["name"]) == _norm_name(server_name),
                 lambda a: _norm_name(server_name).startswith(_norm_name(os.path.splitext(a["name"])[0]))):
        found = [a for a in attachments if test(a)]
        if len(found) == 1:
            return found[0]["index"]
    return None


def now_text() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def log_time() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def one_line(value) -> str:
    return " ".join(str(value or "").split())


def log_summary(detail: dict) -> str:
    """One line for the text file and the CSV."""
    if detail.get("message") or detail.get("reason") or detail.get("error"):
        return one_line(detail.get("message") or detail.get("reason") or detail.get("error"))
    if detail.get("best"):
        return one_line(f"best rule {detail['best']['rule']} score {detail['best']['score']}")
    plan = detail.get("plan")
    if not plan:
        return ""
    failed = [f"{r['action']} failed: {r['error']}" for r in detail.get("results") or [] if not r["ok"]]
    return one_line("; ".join([w["rule"] for w in plan["winners"]] + failed))


def folder_path(full_path: str) -> str:
    """'\\\\\\\\Store\\\\Inbox\\\\Court' -> 'Inbox/Court'"""
    return "/".join([p for p in (full_path or "").split("\\") if p][1:])


def read_pdf(data: bytes) -> tuple:
    """(text, pages). Text layer only: scanned PDFs have no text here (no OCR on this PC)."""
    try:
        from pypdf import PdfReader

        reader = PdfReader(io.BytesIO(data))
        return "\n".join((p.extract_text() or "") for p in reader.pages), len(reader.pages)
    except Exception:
        return "", None


class Automation:
    def __init__(self, source_factory, data_dir: str | None = None):
        self.source_factory = source_factory
        self.dir = data_dir or os.environ.get("OUTLOOK_READER_DATA") or os.path.join(HOME, "automation_data")
        self.drop_dir = os.path.join(self.dir, "import")
        os.makedirs(self.drop_dir, exist_ok=True)
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.wake = threading.Event()  # new settings or rules: check now, don't wait for the timer
        self.last_poll, self.last_error = None, None
        self.last_prune = None
        self.last_processed, self.waiting = 0, 0
        self.logs_dir = os.path.join(self.dir, "logs")
        os.makedirs(self.logs_dir, exist_ok=True)
        with self._db() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS processed (key TEXT PRIMARY KEY, at TEXT, sender TEXT, status TEXT)""")
            db.execute("""CREATE TABLE IF NOT EXISTS log (id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT, mode TEXT, account TEXT,
                          folder TEXT, sender TEXT, subject TEXT, status TEXT, detail TEXT)""")
            if "template" not in [c[1] for c in db.execute("PRAGMA table_info(processed)")]:
                db.execute("ALTER TABLE processed ADD COLUMN template TEXT")
            have = [c[1] for c in db.execute("PRAGMA table_info(log)")]
            for column, kind in (("template", "TEXT"), ("rule", "TEXT"), ("duration_ms", "INTEGER"), ("received", "TEXT")):
                if column not in have:
                    db.execute(f"ALTER TABLE log ADD COLUMN {column} {kind}")
            db.execute("CREATE INDEX IF NOT EXISTS ix_processed_sender ON processed (sender, at)")
            db.execute("""CREATE TABLE IF NOT EXISTS runs (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, mode TEXT, engine TEXT,
                          folders TEXT, date_from TEXT, date_to TEXT, started TEXT, finished TEXT, status TEXT, note TEXT,
                          server_run_id INTEGER)""")
            have = [c[1] for c in db.execute("PRAGMA table_info(log)")]
            for column, kind in (("run_id", "INTEGER"), ("server_item_id", "INTEGER"), ("engine", "TEXT")):
                if column not in have:
                    db.execute(f"ALTER TABLE log ADD COLUMN {column} {kind}")
            db.execute("CREATE INDEX IF NOT EXISTS ix_log_run ON log (run_id)")
            # runs left open by a crash / closed window
            db.execute("UPDATE runs SET status = 'STOPPED', finished = ? WHERE status = 'RUNNING'", (log_time(),))
        self.settings = {**DEFAULTS, **self._read("settings.json", {})}
        self.templates = self._read("templates.json", [])  # one per template id, in import order
        self.monitor_run = None        # local run id of today's monitoring report
        self.backfill = {"running": False}
        self.server_state = {"ok": None, "error": None, "client": None, "checked": None}

    # ---- storage -------------------------------------------------------------
    def _db(self):
        return sqlite3.connect(os.path.join(self.dir, "automation.db"), timeout=15)

    def _read(self, name, default):
        try:
            with open(os.path.join(self.dir, name), encoding="utf-8") as fh:
                return json.load(fh)
        except (OSError, ValueError):
            return default

    def _write(self, name, data) -> None:
        path = os.path.join(self.dir, name)
        with open(path + ".tmp", "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
        os.replace(path + ".tmp", path)

    def _log(self, mode, account, folder, sender, subject, status, detail, template=None, rule=None, duration_ms=None, received=None,
             run_id=None, server_item_id=None, engine=None) -> None:
        at = log_time()
        with self._db() as db:
            db.execute("""INSERT INTO log (at, mode, account, folder, sender, subject, status, detail, template, rule, duration_ms, received,
                          run_id, server_item_id, engine) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                       (at, mode, account, folder, sender, subject, status, json.dumps(detail, default=str), template, rule, duration_ms, received,
                        run_id, server_item_id, engine))
        self._log_file(at, mode, account, folder, sender, subject, status, detail, template, rule, duration_ms)

    def _log_file(self, at, mode, account, folder, sender, subject, status, detail, template, rule, duration_ms) -> None:
        """A full disk or a locked file must never stop the processing: the log table still has the entry."""
        parts = [at, mode, status, "/".join(x for x in (account, folder) if x), sender, subject,
                 f"template={template}" if template else "", f"rule={rule}" if rule else "",
                 f"{duration_ms}ms" if duration_ms is not None else "", log_summary(detail)]
        lines = [" | ".join(one_line(x) for x in parts if x)]
        lines += [f"    [{'OK' if st.get('ok') else 'INFO' if st.get('ok') is None else 'FAIL'}] {one_line(st.get('step'))}: {one_line(st.get('text'))}"
                  for st in detail.get("steps") or []]
        if detail.get("traceback"):
            lines += ["    " + line for line in str(detail["traceback"]).splitlines()]
        try:
            with self.lock, open(os.path.join(self.logs_dir, f"automation-{at[:10]}.log"), "a", encoding="utf-8") as fh:
                fh.write("\n".join(lines) + "\n")
        except OSError:
            traceback.print_exc()

    LOG_COLUMNS = ("id", "at", "mode", "account", "folder", "sender", "subject", "status", "detail", "template", "rule", "duration_ms", "received",
                   "run_id", "server_item_id", "engine")

    def _log_where(self, status="", q="", date_from="", date_to="", run_id="") -> tuple:
        where, args = [], []
        if run_id:
            where.append("run_id = ?")
            args.append(int(run_id))
        if status == "PROBLEMS":
            where.append(f"status IN ({','.join('?' * len(PROBLEMS))})")
            args += PROBLEMS
        elif status:
            where.append("status = ?")
            args.append(status)
        if q:
            where.append("instr(lower(coalesce(subject,'') || ' ' || coalesce(sender,'') || ' ' || coalesce(template,'') || ' ' || coalesce(rule,'') || ' ' || coalesce(folder,'')), ?) > 0")
            args.append(q.lower())
        if date_from:
            where.append("substr(at, 1, 10) >= ?")
            args.append(date_from)
        if date_to:
            where.append("substr(at, 1, 10) <= ?")
            args.append(date_to)
        return (" WHERE " + " AND ".join(where)) if where else "", args

    def log_rows(self, limit: int = 200, offset: int = 0, **filters) -> list:
        where, args = self._log_where(**filters)
        with self._db() as db:
            rows = db.execute(f"SELECT {','.join(self.LOG_COLUMNS)} FROM log{where} ORDER BY id DESC LIMIT ? OFFSET ?", (*args, limit, offset)).fetchall()
        return [{**dict(zip(self.LOG_COLUMNS, r)), "detail": json.loads(r[8] or "{}")} for r in rows]

    def log_page(self, limit: int = 50, offset: int = 0, **filters) -> dict:
        """One page of the Activity screen, its total, and today's counts per result."""
        where, args = self._log_where(**filters)
        with self._db() as db:
            total = db.execute(f"SELECT count(*) FROM log{where}", args).fetchone()[0]
            today = dict(db.execute("SELECT status, count(*) FROM log WHERE substr(at, 1, 10) = ? GROUP BY status",
                                    (datetime.now().strftime("%Y-%m-%d"),)).fetchall())
        return {"items": self.log_rows(limit, offset, **filters), "total": total, "today": today, "logs_folder": self.logs_dir}

    # ---- import --------------------------------------------------------------
    def import_bundle(self, bundle, file_name: str = "") -> dict:
        """
        Adds the template, or replaces the one with the same id. This PC serves one client.
        A NEW forward address switches LIVE back to DRY_RUN and forwarding off, so it gets reviewed first.
        """
        try:
            result = self._import(bundle)
        except Exception as exc:
            self._log(self.settings["mode"], "", "", "", file_name or "Template file", "IMPORT_FAILED", {"error": str(exc)})
            raise
        names = bundle["template"]["name"]
        message = f"{result['rule_count']} rule(s)" + (". Back to Dry run with forwarding off, for review" if result["needs_review"] else "")
        self._log(self.settings["mode"], "", "", "", f"Template imported: {names}", "IMPORTED",
                  {"message": message, "new_forward_addresses": result["new_forward_addresses"]}, template=names)
        return result

    def _import(self, bundle) -> dict:
        validate_bundle(bundle)
        with self.lock:
            current = self.templates[0]["client"] if self.templates else None
            if current and current.get("id") != (bundle.get("client") or {}).get("id"):
                raise ValueError(f"This PC has templates of client '{current.get('name')}'. Remove them first to import "
                                 f"'{(bundle.get('client') or {}).get('name')}'.")
            new_forward = forward_recipients([bundle]) - forward_recipients(self.templates)
            first = not self.templates
            review = first or bool(new_forward)
            if review and self.settings["mode"] == "LIVE":
                self.settings["mode"] = "DRY_RUN"
            if review:
                self.settings["allow_forward"] = False
            tid = bundle["template"]["id"]
            if any(t["template"]["id"] == tid for t in self.templates):
                self.templates = [bundle if t["template"]["id"] == tid else t for t in self.templates]
            else:
                self.templates = self.templates + [bundle]
            self._write("templates.json", self.templates)
            self._write("settings.json", self.settings)
        self.wake.set()
        return {**self.status(), "needs_review": review, "new_forward_addresses": sorted(new_forward),
                "rule_count": len(bundle.get("rules") or [])}

    def remove_template(self, template_id: int) -> dict:
        with self.lock:
            names = [t["template"]["name"] for t in self.templates if t["template"]["id"] == template_id]
            self.templates = [t for t in self.templates if t["template"]["id"] != template_id]
            self._write("templates.json", self.templates)
        for name in names:
            self._log(self.settings["mode"], "", "", "", f"Template removed: {name}", "TEMPLATE_REMOVED", {}, template=name)
        return self.status()

    def _drop_folder(self) -> None:
        """Files copied into automation_data/import are imported by themselves."""
        for name in sorted(os.listdir(self.drop_dir)):
            path = os.path.join(self.drop_dir, name)
            if not name.lower().endswith(".json") or not os.path.isfile(path):
                continue
            target = "failed"
            try:
                with open(path, encoding="utf-8-sig") as fh:
                    data = json.load(fh)
            except (OSError, ValueError) as exc:
                self._log(self.settings["mode"], "", "", "", name, "IMPORT_FAILED", {"error": f"Cannot read the file: {exc}"})
            else:
                try:
                    self.import_bundle(data, name)
                    target = "imported"
                except Exception:
                    pass  # already logged by import_bundle
            os.makedirs(os.path.join(self.dir, target), exist_ok=True)
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S_")
            shutil.move(path, os.path.join(self.dir, target, stamp + name))

    # ---- settings ------------------------------------------------------------
    def update_settings(self, body: dict) -> dict:
        with self.lock:
            s = self.settings
            before = {"mode": s["mode"], "allow_forward": s["allow_forward"], "poll_seconds": s["poll_seconds"], "output_dir": s["output_dir"],
                      "watches": sorted(w.get("path", "") for w in s["watches"]), "engine": s["engine"], "server_url": s["server_url"],
                      "server_key": "set" if s["server_key"] else "not set"}
            if "server_url" in body:
                s["server_url"] = str(body["server_url"] or "").strip()
            if body.get("server_key"):  # empty = keep the saved key
                s["server_key"] = str(body["server_key"]).strip()
            if body.get("clear_server_key"):
                s["server_key"] = ""
            if "engine" in body:
                if body["engine"] not in ENGINES:
                    raise ValueError(f"engine must be one of {ENGINES}")
                if body["engine"] == "SERVER" and not (s["server_url"] and s["server_key"]):
                    raise ValueError("Set the server address and the connector key first")
                s["engine"] = body["engine"]
            if s["engine"] == "SERVER" and not (s["server_url"] and s["server_key"]):
                s["engine"] = "LOCAL"
            if "mode" in body:
                if body["mode"] not in MODES:
                    raise ValueError(f"mode must be one of {MODES}")
                if body["mode"] != "OFF" and s["mode"] == "OFF":  # only new mail from now on, not the backlog
                    for w in s["watches"]:
                        w["since"] = now_text()
                s["mode"] = body["mode"]
            if "allow_forward" in body:
                s["allow_forward"] = bool(body["allow_forward"])
            if "poll_seconds" in body:
                s["poll_seconds"] = max(10, min(int(body["poll_seconds"]), 3600))
            if "output_dir" in body:
                s["output_dir"] = str(body["output_dir"]).strip()
            if "watches" in body:
                known = {(w["store"], w["folder"]): w for w in s["watches"]}
                s["watches"] = [{"store": w["store"], "folder": w["folder"], "account": w.get("account", ""),
                                 "account_email": w.get("account_email", ""), "path": w.get("path", ""),
                                 "since": known.get((w["store"], w["folder"]), {}).get("since") or now_text()}
                                for w in body["watches"]]
            self._write("settings.json", s)
            after = {**s, "watches": sorted(w.get("path", "") for w in s["watches"]),
                     "server_key": "set" if s["server_key"] else "not set"}
            changes = [f"{k}: {before[k]} -> {after[k]}" for k in before if before[k] != after[k]]
        if changes:
            self._log(s["mode"], "", "", "", "Settings changed", "SETTINGS_CHANGED", {"message": "; ".join(changes)})
        if before["mode"] != s["mode"] or before["engine"] != s["engine"]:
            self.close_monitor_run("mode changed")  # the next email starts a new report with the new mode
        if before["server_url"] != s["server_url"] or before["server_key"] != after["server_key"]:
            self.server_state = {"ok": None, "error": None, "client": None, "checked": None}
        self.wake.set()
        return self.status()

    # ---- server (Rule Management in the LAN) ----------------------------------
    def client(self) -> ServerClient:
        return ServerClient(self.settings["server_url"], self.settings["server_key"], VERSION, self.settings["mode"])

    def server_test(self) -> dict:
        try:
            info = self.client().ping()
            self.server_state = {"ok": True, "error": None, "client": info.get("client"), "checked": log_time(), "key": info.get("key")}
        except (ServerError, ServerUnavailable) as exc:
            self.server_state = {"ok": False, "error": str(exc), "client": None, "checked": log_time()}
        return self.server_state

    def server_templates(self) -> list:
        imported = {t["template"]["id"]: t.get("exported_at") for t in self.templates}
        return [{**t, "imported": t["id"] in imported, "imported_at": imported.get(t["id"])} for t in self.client().templates()]

    def import_from_server(self, template_id: int) -> dict:
        bundle = self.client().template_bundle(template_id)
        return self.import_bundle(bundle, f"server template {template_id}")

    def sync_from_server(self) -> dict:
        """Download every imported template again (rules changed on the server)."""
        done, failed = [], []
        for t in list(self.templates):
            tid = t["template"]["id"]
            try:
                self.import_from_server(tid)
                done.append(t["template"]["name"])
            except (ServerError, ServerUnavailable, ValueError) as exc:
                failed.append(f"{t['template']['name']}: {exc}")
        return {**self.status(), "updated": done, "failed": failed}

    def output_dir(self) -> str:
        return self.settings["output_dir"] or os.path.join(self.dir, "output")

    def status(self) -> dict:
        templates = [{"id": t["template"]["id"], "name": t["template"]["name"], "description": t["template"].get("description"),
                      "client": t.get("client"), "exported_at": t.get("exported_at"), "filters": t.get("filters") or {},
                      "rules": [{"name": r.get("name"), "version": r.get("version"), "scope": r.get("scope"),
                                 "keywords": r.get("keywords") or [], "actions": [a.get("type") for a in r.get("actions") or []],
                                 **compatibility(r)} for r in t.get("rules", [])]} for t in self.templates]
        settings = {**self.settings, "server_key": ""}
        key = self.settings.get("server_key") or ""
        return {"settings": settings, "server": {**self.server_state, "key_set": bool(key), "key_hint": key[-6:] if key else None},
                "backfill": {k: v for k, v in self.backfill.items() if k != "stop"}, "monitor_run": self.monitor_run,
                "version": VERSION, "output_dir": self.output_dir(), "drop_folder": self.drop_dir,
                "last_poll": self.last_poll, "last_error": self.last_error, "last_processed": self.last_processed,
                "waiting": self.waiting, "templates": templates,
                "forward_addresses": sorted(forward_recipients(self.templates))}

    # ---- one email -----------------------------------------------------------
    def check_message(self, source, store: str, entry_id: str, folder: str, account_email: str, files: dict | None = None, steps: list | None = None) -> tuple:
        """(message, decision or None, skip reason or None). Changes nothing. files keeps the PDFs read, by index; steps collects the trace."""
        steps = [] if steps is None else steps
        msg = source.message(store, entry_id)
        docs, reasons = None, []
        for t in self.templates:
            name, filters = t["template"]["name"], t.get("filters") or {}
            skip = filter_skip(filters, msg, folder, account_email)
            if not skip:
                if docs is None:  # read PDFs only once a template could apply
                    docs = self._documents(source, store, entry_id, msg, files, steps)
                skip = body_filter_skip(filters, docs)
            if skip:
                reasons.append(f"{name}: {skip}")
                steps.append({"step": "Template", "ok": False, "text": f"{name} does not apply: {skip}"})
                continue
            steps.append({"step": "Template", "ok": True, "text": f"{name} applies"})
            return msg, {**decide(t.get("rules", []), msg, docs), "template": name,
                         "max_per_day": filters.get("max_emails_per_sender_per_day")}, None
        return msg, None, "; ".join(reasons) or "no templates imported"

    def _documents(self, source, store: str, entry_id: str, msg: dict, files: dict | None, steps: list) -> list:
        pdfs = []
        for a in msg.get("attachments") or []:
            name = a.get("name", "")
            if not str(name).lower().endswith(".pdf"):
                steps.append({"step": "Attachment", "ok": None, "text": f"{name}: not a PDF, not read"})
            elif (a.get("size") or 0) > MAX_PDF_BYTES:
                steps.append({"step": "Attachment", "ok": False, "text": f"{name}: larger than {MAX_PDF_BYTES // 1048576} MB, not read"})
            else:
                try:
                    data = source.attachment(store, entry_id, a["index"])[1]
                    if files is not None:
                        files[a["index"]] = data
                    text, pages = read_pdf(data)
                    if pages is None:
                        steps.append({"step": "Attachment", "ok": False, "text": f"{name}: the PDF could not be read"})
                    elif not text.strip():
                        steps.append({"step": "Attachment", "ok": False, "text": f"{name}: {pages} page(s), no text (scanned PDF? no OCR on this PC)"})
                    else:
                        steps.append({"step": "Attachment", "ok": True, "text": f"{name}: {pages} page(s), {len(text)} characters read"})
                except Exception as exc:
                    text, pages = "", None
                    steps.append({"step": "Attachment", "ok": False, "text": f"{name}: could not be opened: {exc}"})
                pdfs.append({"index": a["index"], "file_name": a["name"], "text": text, "page_count": pages})
        return build_documents(msg, pdfs)

    def _save_file(self, source, store: str, entry_id: str, f: dict, files: dict) -> str:
        data = files[f["index"]] if f["index"] in files else source.attachment(store, entry_id, f["index"])[1]
        root = os.path.abspath(self.output_dir())
        target_dir = os.path.join(root, *folder_parts(f["folder"]))
        os.makedirs(target_dir, exist_ok=True)
        base, ext = os.path.splitext(safe_name(f["new_name"]))
        path, n = os.path.join(target_dir, base + ext), 1
        while os.path.exists(path):  # never overwrite an earlier file
            path, n = os.path.join(target_dir, f"{base}_{n}{ext}"), n + 1
        with open(path, "wb") as fh:
            fh.write(data)
        return path

    def execute(self, source, store: str, entry_id: str, plan: dict, files: dict | None = None) -> list:
        """Run the plan. The move is last because it can change the email's id."""
        results = []

        def step(kind, what, fn):
            started = time.monotonic()
            try:
                results.append({"action": kind, "what": what, "ok": True, "result": fn(), "ms": int((time.monotonic() - started) * 1000)})
            except Exception as exc:
                results.append({"action": kind, "what": what, "ok": False, "error": str(exc), "ms": int((time.monotonic() - started) * 1000)})

        if plan["categories"]:
            step("CATEGORY", ", ".join(plan["categories"]), lambda: source.add_categories(store, entry_id, plan["categories"]))
        for f in plan["files"]:
            step("SAVE_ATTACHMENT", f["file_name"], lambda f=f: self._save_file(source, store, entry_id, f, files or {}))
        if plan["forward"]:
            if self.settings["allow_forward"]:
                step("FORWARD", ", ".join(plan["forward"]), lambda: source.forward(store, entry_id, plan["forward"]))
            else:
                results.append({"action": "FORWARD", "what": ", ".join(plan["forward"]), "ok": False,
                                "error": "not sent: forwarding is not allowed in the settings", "ms": 0})
        if plan["move"]:
            step("MOVE_EMAIL", plan["move"]["folder"], lambda: source.move(store, entry_id, plan["move"]["folder"]))
        return results

    # ---- runs (reports) --------------------------------------------------------
    def open_run(self, kind: str, mode: str, folders: list, date_from=None, date_to=None, note=None) -> int:
        with self._db() as db:
            cur = db.execute("""INSERT INTO runs (kind, mode, engine, folders, date_from, date_to, started, status, note)
                                VALUES (?,?,?,?,?,?,?,?,?)""", (kind, mode, self.settings["engine"], json.dumps(folders), date_from, date_to,
                                                                log_time(), "RUNNING", note))
            run_id = cur.lastrowid
        self._server_run(run_id)
        return run_id

    def _server_run(self, run_id):
        """The server's run id for this local run (created on the server the first time it is needed)."""
        if not run_id or self.settings["engine"] != "SERVER":
            return None
        with self._db() as db:
            row = db.execute("SELECT server_run_id, kind, mode, folders, date_from, date_to, engine FROM runs WHERE id = ?", (run_id,)).fetchone()
        if row is None or row[6] != "SERVER":
            return None
        if row[0]:
            return row[0]
        try:
            sid = self.client().start_run(row[1], row[2], json.loads(row[3] or "[]"), row[4], row[5])["id"]
        except (ServerError, ServerUnavailable):
            return None  # tried again with the next email
        with self._db() as db:
            db.execute("UPDATE runs SET server_run_id = ? WHERE id = ?", (sid, run_id))
        return sid

    def close_run(self, run_id, status: str = "COMPLETED", note: str = None) -> None:
        if not run_id:
            return
        with self._db() as db:
            db.execute("UPDATE runs SET status = ?, finished = ?, note = coalesce(?, note) WHERE id = ? AND status = 'RUNNING'",
                       (status, log_time(), note, run_id))
            row = db.execute("SELECT server_run_id FROM runs WHERE id = ?", (run_id,)).fetchone()
        if row and row[0]:
            try:
                self.client().update_run(row[0], status, note)
            except (ServerError, ServerUnavailable):
                pass  # the web panel shows it as running; the local report is complete

    def _monitor_run_id(self) -> int:
        """One monitoring report per day (and per mode / engine)."""
        today = datetime.now().strftime("%Y-%m-%d")
        if self.monitor_run:
            with self._db() as db:
                row = db.execute("SELECT started, status FROM runs WHERE id = ?", (self.monitor_run,)).fetchone()
            if row and row[1] == "RUNNING" and row[0][:10] == today:
                return self.monitor_run
            self.close_run(self.monitor_run)
        self.monitor_run = self.open_run("LIVE_MONITOR", self.settings["mode"], [w.get("path", "") for w in self.settings["watches"]],
                                         note="new emails in the watched folders")
        return self.monitor_run

    def close_monitor_run(self, note: str = None) -> None:
        if self.monitor_run:
            self.close_run(self.monitor_run, "COMPLETED", note)
            self.monitor_run = None

    def runs(self, limit: int = 50) -> list:
        with self._db() as db:
            rows = db.execute("""SELECT id, kind, mode, engine, folders, date_from, date_to, started, finished, status, note, server_run_id
                                 FROM runs ORDER BY id DESC LIMIT ?""", (limit,)).fetchall()
            counts = {}
            ids = [r[0] for r in rows]
            if ids:
                for run_id, status, n, ms in db.execute(
                        f"SELECT run_id, status, count(*), sum(duration_ms) FROM log WHERE run_id IN ({','.join('?' * len(ids))}) "
                        "AND status NOT LIKE 'BACKFILL%' GROUP BY run_id, status", ids):  # emails only, not the job's start / end
                    c = counts.setdefault(run_id, {"total": 0, "ms": 0})
                    c[status] = n
                    c["total"] += n
                    c["ms"] += ms or 0
        keys = ("id", "kind", "mode", "engine", "folders", "date_from", "date_to", "started", "finished", "status", "note", "server_run_id")
        return [{**dict(zip(keys, r)), "folders": json.loads(r[4] or "[]"), "totals": counts.get(r[0], {"total": 0})} for r in rows]

    # ---- one email ----------------------------------------------------------------
    def process(self, source, watch: dict, row: dict, key: str, run_id=None, mode=None, again: bool = False) -> None:
        """
        One email, LOCAL or SERVER engine. again=True: also when it was processed before (old-email job with "process again").
        ServerUnavailable is raised (and the email is NOT marked as processed): it is tried again later.
        """
        mode = mode or self.settings["mode"]
        sender = (row.get("sender_email") or row.get("sender") or "").lower()
        with self._db() as db:
            db.execute(("INSERT OR REPLACE" if again else "INSERT OR IGNORE") + " INTO processed (key, at, sender, status) VALUES (?,?,?,?)",
                       (key, now_text(), sender, "STARTED"))
        if self.settings["engine"] == "SERVER":
            return self._process_server(source, watch, row, key, run_id, mode, sender)
        return self._process_local(source, watch, row, key, run_id, mode, sender)

    def _process_local(self, source, watch: dict, row: dict, key: str, run_id, mode: str, sender: str) -> None:
        store, entry_id = watch["store"], row["id"]
        status, detail, template, steps, started = "ERROR", {}, None, [], time.monotonic()
        rule = None
        try:
            files = {}  # the PDFs are read once: for matching, then reused when saving
            _, plan, skip = self.check_message(source, store, entry_id, watch.get("path", ""), watch.get("account_email", ""), files, steps)
            if skip:
                status, detail = "SKIPPED", {"reason": skip}
            else:
                template = plan["template"]
                for c in plan.pop("checked"):
                    steps.append(self._rule_step(c))
                if plan["max_per_day"] and self._sender_today(sender, template) >= plan["max_per_day"]:
                    status, detail = "SKIPPED", {"reason": f"{template}: more than {plan['max_per_day']} emails from this sender today"}
                elif not plan["winners"]:
                    status, detail = "NO_MATCH", {"template": template, "best": plan["best"]}
                else:
                    rule = ", ".join(w["rule"] for w in plan["winners"])
                    status, detail = "MATCHED", {"plan": plan}
                    if mode == "LIVE":
                        detail["results"] = self.execute(source, store, entry_id, plan, files)
                        if any(not r["ok"] for r in detail["results"]):
                            detail["partial"] = True
                        for r in detail["results"]:
                            done = f"{r['what']}: " + (str(r.get("result") or "done") if r["ok"] else str(r["error"]))
                            steps.append({"step": r["action"], "ok": r["ok"], "text": f"{done} ({r['ms']} ms)"})
                    else:
                        steps.append({"step": "Actions", "ok": None, "text": "Dry run: nothing was changed"})
        except Exception as exc:
            detail = {"error": str(exc), "traceback": traceback.format_exc()}
            steps.append({"step": "Error", "ok": False, "text": f"{exc}. This email is not tried again."})
        detail["steps"] = steps
        with self._db() as db:
            db.execute("UPDATE processed SET status = ?, template = ? WHERE key = ?", (status, template, key))
        self._log(mode, watch.get("account", ""), watch.get("path", ""), row.get("sender_email") or row.get("sender"),
                  row.get("subject"), "PARTIAL" if detail.get("partial") else status, detail, template=template, rule=rule,
                  duration_ms=int((time.monotonic() - started) * 1000), received=row.get("received"), run_id=run_id, engine="LOCAL")


    def _process_server(self, source, watch: dict, row: dict, key: str, run_id, mode: str, sender: str) -> None:
        """The server analyses and decides, this PC carries out the actions in Outlook and reports back."""
        store, entry_id = watch["store"], row["id"]
        folder, account = watch.get("path", ""), watch.get("account", "")
        steps, started, detail = [], time.monotonic(), {}
        status, template, rule, item_id = "ERROR", None, None, None
        client = self.client()
        server_run = self._server_run(run_id)
        base = {"run_id": server_run, "account": account, "folder": folder, "subject": row.get("subject"),
                "sender": row.get("sender_email") or row.get("sender"), "received": row.get("received"), "outlook_id": key, "mode": mode}
        try:
            msg = source.message(store, entry_id)
            tpl, reasons = None, []
            for t in self.templates:  # mailbox / folder / sender / subject: checked here, Outlook knows them for sure
                skip = filter_skip(t.get("filters") or {}, msg, folder, watch.get("account_email", ""))
                if not skip:
                    tpl = t
                    break
                reasons.append(f"{t['template']['name']}: {skip}")
                steps.append({"step": "Template", "ok": False, "text": f"{t['template']['name']} does not apply: {skip}"})
            if tpl is None:
                status, detail = "SKIPPED", {"reason": "; ".join(reasons) or "no templates imported"}
                try:
                    item_id = client.add_item({**base, "status": "SKIPPED", "steps": steps, "error": None,
                                               "total_ms": int((time.monotonic() - started) * 1000)})["id"]
                except ServerError:
                    pass
            else:
                template = tpl["template"]["name"]
                filters = tpl.get("filters") or {}
                steps.append({"step": "Template", "ok": True, "text": f"{template} applies"})
                if filters.get("max_emails_per_sender_per_day") and self._sender_today(sender, template) >= filters["max_emails_per_sender_per_day"]:
                    status = "SKIPPED"
                    detail = {"reason": f"{template}: more than {filters['max_emails_per_sender_per_day']} emails from this sender today"}
                    item_id = client.add_item({**base, "status": "SKIPPED", "template_name": template, "steps": steps,
                                               "error": detail["reason"]})["id"]
                else:
                    files, atts = {}, []
                    for a in msg.get("attachments") or []:
                        if (a.get("size") or 0) > MAX_PDF_BYTES:
                            steps.append({"step": "Attachment", "ok": False, "text": f"{a['name']}: larger than {MAX_PDF_BYTES // 1048576} MB, not sent"})
                            continue
                        data = source.attachment(store, entry_id, a["index"])[1]
                        files[a["index"]] = data
                        atts.append((a["name"], data))
                        steps.append({"step": "Attachment", "ok": True, "text": f"{a['name']}: {len(data) // 1024} KB sent to the server"})
                    sent = time.monotonic()
                    res = client.process(build_eml(msg, atts), {**base, "template_id": tpl["template"]["id"]})
                    item_id, status = res["id"], res["status"]
                    steps.append({"step": "Server", "ok": status != "ERROR",
                                  "text": f"analysed in {time.monotonic() - sent:.1f} s, result {status}"
                                          + (f" (email #{res['email_id']} in the web panel)" if res.get("email_id") else "")})
                    steps += [{"step": f"Server · {st.get('step')}", "ok": st.get("ok"), "text": st.get("text")} for st in res.get("steps") or []]
                    plan = res.get("plan") or {}
                    rule = res.get("rule_names")
                    detail = {"server_item": item_id, "documents": res.get("documents"), "error": res.get("error")}
                    own = []  # steps of this PC, reported back
                    if status == "MATCHED":
                        for f in plan.get("files") or []:
                            f["index"] = match_attachment(f["file_name"], msg.get("attachments") or [])
                        missing = [f for f in plan.get("files") or [] if f["index"] is None]
                        plan["files"] = [f for f in plan.get("files") or [] if f["index"] is not None]
                        plan.setdefault("categories", [])
                        plan.setdefault("forward", [])
                        detail["plan"] = plan
                        if mode == "LIVE":
                            results = self.execute(source, store, entry_id, plan, files)
                            results += [{"action": "SAVE_ATTACHMENT", "what": f["file_name"], "ok": False, "ms": 0,
                                         "error": "attachment not found in the Outlook email"} for f in missing]
                            detail["results"] = results
                            for r in results:
                                done = f"{r['what']}: " + (str(r.get("result") or "done") if r["ok"] else str(r["error"]))
                                own.append({"step": r["action"], "ok": r["ok"], "text": f"{done} ({r['ms']} ms)"})
                            failed = [r for r in results if not r["ok"]]
                            status = "MATCHED" if not failed else ("PARTIAL" if len(failed) < len(results) else "ACTION_FAILED")
                            report = {"action_results": results, "status": "DONE" if not failed else status}
                        else:
                            own.append({"step": "Actions", "ok": None, "text": "Dry run: nothing was changed in Outlook"})
                            report = {"status": "MATCHED"}
                    else:
                        report = {}
                    steps += own
                    try:
                        client.finish_item(item_id, {**report, "steps": own, "total_ms": int((time.monotonic() - started) * 1000)})
                    except (ServerError, ServerUnavailable) as exc:
                        steps.append({"step": "Report", "ok": False, "text": f"result not sent to the server: {exc}"})
        except ServerUnavailable as exc:
            with self._db() as db:  # not processed: tried again when the server is back
                db.execute("DELETE FROM processed WHERE key = ?", (key,))
            raise
        except Exception as exc:
            detail = {**detail, "error": str(exc), "traceback": traceback.format_exc()}
            steps.append({"step": "Error", "ok": False, "text": f"{exc}. This email is not tried again."})
            if item_id is None:
                try:
                    item_id = client.add_item({**base, "status": "ERROR", "template_name": template, "error": str(exc)[:2000], "steps": steps})["id"]
                except (ServerError, ServerUnavailable):
                    pass
        detail["steps"] = steps
        with self._db() as db:
            db.execute("UPDATE processed SET status = ?, template = ? WHERE key = ?", (status, template, key))
        self._log(mode, account, folder, row.get("sender_email") or row.get("sender"), row.get("subject"), status, detail,
                  template=template, rule=rule, duration_ms=int((time.monotonic() - started) * 1000), received=row.get("received"),
                  run_id=run_id, server_item_id=item_id, engine="SERVER")

    @staticmethod
    def _rule_step(c: dict) -> dict:
        if c.get("not_runnable"):
            return {"step": "Rule", "ok": False, "text": f"{c['rule']}: cannot run on this PC"}
        where = f"{c['rule']} on {c['document']}: score {c['score']}"
        if c.get("already_claimed"):
            return {"step": "Rule", "ok": None, "text": f"{where}, matched but an earlier rule already took it"}
        if c["matched"]:
            return {"step": "Rule", "ok": True, "text": f"{where}, matched"}
        why = f"blocked by {'; '.join(str(b) for b in c['blocked_by'])}" if c.get("blocked_by") else f"below the threshold {c.get('threshold')}"
        return {"step": "Rule", "ok": False, "text": f"{where}, {why}"}

    def _sender_today(self, sender: str, template: str) -> int:
        with self._db() as db:
            return db.execute("SELECT count(*) FROM processed WHERE sender = ? AND template = ? AND at >= ? AND status = 'MATCHED'",
                              (sender, template, datetime.now().strftime("%Y-%m-%d"))).fetchone()[0]

    # ---- worker --------------------------------------------------------------
    def poll_once(self, source) -> int:
        with self.lock:
            mode = self.settings["mode"]
            watches = [dict(w) for w in self.settings["watches"]]
        if mode == "OFF" or not self.templates:
            return 0
        done, waiting = 0, 0
        for watch in watches:
            since = watch.get("since") or now_text()
            rows = source.messages(watch["store"], watch["folder"], limit=500, since=since[:10])["items"]
            rows = sorted((r for r in rows if (r.get("received") or "") >= since), key=lambda r: r.get("received") or "")
            keys = {r["id"]: r.get("internet_id") or source.internet_id(watch["store"], r["id"]) or f"{watch['store']}|{r['id']}"
                    for r in rows}  # the id normally comes with the list: no need to open each email
            seen = self._seen(list(keys.values()))
            todo = [r for r in rows if keys[r["id"]] not in seen]
            for row in todo[:MAX_PER_POLL]:
                try:
                    self.process(source, watch, row, keys[row["id"]], run_id=self._monitor_run_id())
                except ServerUnavailable as exc:
                    self._server_down(exc)
                    self.last_processed, self.waiting = done, waiting + len(todo)
                    return done  # the rest waits for the server; the folder's start time is not moved
                done += 1
            if todo:
                self._server_back()
            waiting += max(0, len(todo) - MAX_PER_POLL)
            if rows and len(todo) <= MAX_PER_POLL:  # all done: the next check can start from here
                self._advance(watch, rows[-1].get("received"))
        self.last_processed, self.waiting = done, waiting
        return done

    def _server_down(self, exc) -> None:
        error = str(exc)
        if self.server_state.get("error") != error:  # logged once per problem, not at every check
            self._log(self.settings["mode"], "", "", "", "Rule Management server not reachable", "SERVER_UNREACHABLE",
                      {"error": error, "message": "emails wait and are processed when the server is back"})
        self.server_state = {**self.server_state, "ok": False, "error": error, "checked": log_time()}

    def _server_back(self) -> None:
        if self.settings["engine"] == "SERVER" and self.server_state.get("ok") is False:
            self._log(self.settings["mode"], "", "", "", "Rule Management server reachable again", "CONNECTION_RESTORED", {})
        if self.settings["engine"] == "SERVER":
            self.server_state = {**self.server_state, "ok": True, "error": None, "checked": log_time()}

    # ---- old emails (date / time range) ----------------------------------------
    def start_backfill(self, body: dict) -> dict:
        """
        Process emails that are already in the folders, received between date_from and date_to.
        mode: DRY_RUN (default) or LIVE. again=True also processes emails that were processed before.
        Runs in its own thread with its own Outlook connection; progress in status()["backfill"].
        """
        with self.lock:
            if self.backfill.get("running"):
                raise ValueError("An old-email job is already running. Stop it first.")
            if not self.templates:
                raise ValueError("Import a template first")
            date_from, date_to = parse_when(body.get("date_from")), parse_when(body.get("date_to") or now_text(), end=True)
            if date_from > date_to:
                raise ValueError("'From' is after 'To'")
            mode = body.get("mode") or "DRY_RUN"
            if mode not in ("DRY_RUN", "LIVE"):
                raise ValueError("mode must be DRY_RUN or LIVE")
            watches = body.get("watches") or self.settings["watches"]
            if not watches:
                raise ValueError("Choose at least one folder")
            watches = [{"store": w["store"], "folder": w["folder"], "account": w.get("account", ""),
                        "account_email": w.get("account_email", ""), "path": w.get("path", "")} for w in watches]
            again = bool(body.get("again"))
            run_id = self.open_run("BACKFILL", mode, [w["path"] for w in watches], date_from, date_to,
                                   note="process again" if again else None)
            self.backfill = {"running": True, "stop": False, "run_id": run_id, "mode": mode, "date_from": date_from, "date_to": date_to,
                             "again": again, "found": 0, "done": 0, "already": 0, "current": "", "status": "RUNNING",
                             "started": log_time(), "finished": None, "error": None, "folders": [w["path"] for w in watches]}
        self._log(mode, "", "", "", f"Old-email job started: {date_from} to {date_to}", "BACKFILL_STARTED",
                  {"message": f"{len(watches)} folder(s), {'process again' if again else 'skip emails done before'}"}, run_id=run_id)
        threading.Thread(target=self._backfill_run, args=(watches, again), name="backfill", daemon=True).start()
        return self.status()

    def stop_backfill(self) -> dict:
        self.backfill["stop"] = True
        return self.status()

    def _backfill_rows(self, source, watch: dict, date_from: str, date_to: str) -> list:
        rows, offset = [], 0
        while len(rows) < BACKFILL_MAX:
            page = source.messages(watch["store"], watch["folder"], offset=offset, limit=BACKFILL_PAGE, since=date_from[:10])["items"]
            if not page:
                break
            rows += [r for r in page if date_from <= (r.get("received") or "")[:16] <= date_to]
            if len(page) < BACKFILL_PAGE or min((r.get("received") or "") for r in page)[:16] < date_from:
                break  # newest first: older than the range from here on
            offset += BACKFILL_PAGE
        return sorted(rows[:BACKFILL_MAX], key=lambda r: r.get("received") or "")

    def _backfill_run(self, watches: list, again: bool) -> None:
        b = self.backfill
        status, error = "COMPLETED", None
        try:
            source = self.source_factory()
            work = []
            for w in watches:
                rows = self._backfill_rows(source, w, b["date_from"], b["date_to"])
                work += [(w, r, r.get("internet_id") or source.internet_id(w["store"], r["id"]) or f"{w['store']}|{r['id']}") for r in rows]
            b["found"] = len(work)
            seen = set() if again else self._seen([k for _, _, k in work])
            for w, row, key in work:
                if b["stop"]:
                    status = "STOPPED"
                    break
                if key in seen:
                    b["already"] += 1
                    continue
                b["current"] = f"{row.get('received')} · {row.get('subject')}"[:200]
                self.process(source, w, row, key, run_id=b["run_id"], mode=b["mode"], again=again)
                b["done"] += 1
        except ServerUnavailable as exc:
            status, error = "FAILED", f"server not reachable: {exc}"
            self._server_down(exc)
        except Exception as exc:
            traceback.print_exc()
            status, error = "FAILED", f"{type(exc).__name__}: {exc}"
        b.update(running=False, status=status, error=error, current="", finished=log_time())
        note = f"{b['done']} processed, {b['already']} done before, {b['found']} found" + (f"; {error}" if error else "")
        self.close_run(b["run_id"], status, note)
        self._log(b["mode"], "", "", "", f"Old-email job {status.lower()}", "BACKFILL_" + ("DONE" if status == "COMPLETED" else status),
                  {"message": note, "error": error}, run_id=b["run_id"])

    def _seen(self, keys: list) -> set:
        """Which of these emails were already processed (only looks them up, not the whole history)."""
        seen = set()
        with self._db() as db:
            for i in range(0, len(keys), 500):
                part = keys[i:i + 500]
                seen |= {k for (k,) in db.execute(f"SELECT key FROM processed WHERE key IN ({','.join('?' * len(part))})", part)}
        return seen

    def _prune(self) -> None:
        """Once a day. Safe for processed: each folder's start time has moved past these emails."""
        today = datetime.now().strftime("%Y-%m-%d")
        if self.last_prune == today:
            return
        self.last_prune = today
        cutoff = (datetime.now() - timedelta(days=RETENTION_DAYS)).strftime("%Y-%m-%d")
        with self._db() as db:
            db.execute("DELETE FROM log WHERE at < ?", (cutoff,))
            db.execute("DELETE FROM processed WHERE at < ?", (cutoff,))
        for name in os.listdir(self.logs_dir):
            if name.startswith("automation-") and name.endswith(".log") and name[11:21] < cutoff:
                try:
                    os.remove(os.path.join(self.logs_dir, name))
                except OSError:
                    pass  # open in another program: removed another day

    def _advance(self, watch: dict, received) -> None:
        with self.lock:
            for w in self.settings["watches"]:
                if (w["store"], w["folder"]) == (watch["store"], watch["folder"]) and received and received > w.get("since", ""):
                    w["since"] = received
            self._write("settings.json", self.settings)

    def _run(self) -> None:
        source = None
        while not self.stop_event.is_set():
            try:
                self._drop_folder()
                self._prune()
                if source is None:
                    source = self.source_factory()  # Outlook COM: one connection per thread
                self.poll_once(source)
                if self.last_error:
                    self._log(self.settings["mode"], "", "", "", "Outlook connection restored", "CONNECTION_RESTORED", {})
                self.last_error = None
            except Exception as exc:
                traceback.print_exc()
                error = f"{type(exc).__name__}: {exc}"
                if error != self.last_error:  # once per problem, not at every check
                    self._log(self.settings["mode"], "", "", "", "Could not check Outlook", "CONNECTION_LOST",
                              {"error": error, "traceback": traceback.format_exc()})
                self.last_error = error
                source = None  # e.g. Outlook was closed: connect again next time
            self.last_poll = log_time()
            self.wake.wait(self.settings["poll_seconds"])
            self.wake.clear()

    def start(self) -> None:
        self._log(self.settings["mode"], "", "", "", "Automation started", "STARTED",
                  {"message": f"{len(self.templates)} template(s), {len(self.settings['watches'])} folder(s) watched"})
        threading.Thread(target=self._run, name="automation", daemon=True).start()

    def stop(self) -> None:
        self.backfill["stop"] = True
        self.close_monitor_run("program closed")
        self.stop_event.set()
        self.wake.set()
