// Case number formats vary meaningfully between Florida counties/clerks —
// verified against three real filings with genuinely different layouts:
//   - Palm Beach (15th Circuit) e-filing stamp: a machine-generated line
//     like "**** CASE NUMBER: 502026CA003977XXXAMB Div: AH ****" near the
//     bottom of the document, concatenated with no internal spaces.
//   - Sarasota (12th Circuit) caption: "CASE No. 2020 CA 001231 NC" typed
//     directly in the caption block, space-separated, no colon at all, on
//     its own line.
//   - Broward (17th Circuit) caption: "CASE NO. CACE16006184 DIVISION: 11
//     JUDGE: Garcia-Wood, Marina (11)" — case number, division, AND judge
//     all crammed onto a single line with no newlines between them.
// A single strict regex tuned to one of these misses the others, so this
// matches "CASE NO"/"CASE NUMBER" generically (colon optional) and takes
// the value non-greedily, stopping at whichever comes first: a trailing
// "DIVISION:"/"DIV:"/"JUDGE:" field on the same line, stamp asterisks, or
// end of line — rather than greedily grabbing the whole rest of the line
// (which, on the Broward layout, swallowed "DIVISION: 11 JUDGE: Garcia-
// Wood, Marina (11)" into the case number itself before this fix).
// Requires an alphanumeric first character for the value, not just "not
// whitespace" (\S) or "not whitespace-or-colon" ([^\s:]) — both of those
// still let backtracking leave one of the several optional pieces here
// (\.?, :?, [ \t]*) unconsumed and have the leftover punctuation itself
// satisfy the "content" check on a genuinely blank "CASE NO.:" field
// (first attempt matched value ":  ", second attempt matched ".:" — found
// by actually testing the blank-field case, not just the documents that
// have a real value). A case number can only start with a letter or digit,
// so this closes off every backtracking path that tries to smuggle
// punctuation through as if it were content.
const CASE_LABEL_RE =
  /CASE\s*(?:NO\.?|NUMBER)\s*:?[ \t]*([A-Za-z0-9][A-Za-z0-9 ]*?)(?=[ \t]*(?:DIVISION\s*:|DIV\s*:|JUDGE\s*:|\*|$))/im;

// "Div:" (Palm Beach stamp) and "DIVISION:" (Sarasota/Broward caption) are
// the same field under two different labels — DIV(?:ISION)? covers both —
// and the value itself is sometimes letters ("AH"), sometimes digits
// ("11"), so the value class allows either rather than assuming one.
const DIVISION_RE = /\bDIV(?:ISION)?\s*:?[ \t]*([A-Za-z0-9]{1,4})\b/i;
// "JUDGE: Garcia-Wood, Marina (11)" — stop before the trailing "(11)"
// judge-number parenthetical rather than swallowing it into the name.
const JUDGE_RE = /\bJUDGE\s*:?[ \t]*([A-Za-z][A-Za-z,.'-]*(?:[ \t]+[A-Za-z][A-Za-z,.'-]*)*)/i;

// OCR on a scanned filing misread "CASE" as "GASE" and split the case
// number itself across a stray space ("502026 CA004226XXXAMB") — verified
// on a real scanned document where that broke CASE_LABEL_RE entirely (the
// whole field silently disappeared). Rather than guess at every possible
// OCR letter confusion, this falls back to matching the case number by its
// own rigid shape instead of depending on the label text surviving OCR:
// Florida's Uniform Case Number format is 6 digits (county+year), 2 letters
// (case type), 6 digits (sequence), 3-8 letters (division/judge suffix) —
// distinctive enough that this won't false-positive on ordinary prose.
const UCN_SHAPE_RE = /\b(\d{6})\s*([A-Z]{2})\s*(\d{6})\s*([A-Z]{3,8})\b/;

function addDivisionAndJudge(info, text) {
  const division = DIVISION_RE.exec(text);
  if (division) info["Division"] = division[1];
  const judge = JUDGE_RE.exec(text);
  if (judge) info["Judge"] = judge[1].trim();
  return info;
}

export function extractCaseInfo(text) {
  const labeled = CASE_LABEL_RE.exec(text);
  if (labeled) {
    const value = labeled[1].trim();
    if (value) {
      return addDivisionAndJudge({ "Case Number": value }, text);
    }
  }

  const shaped = UCN_SHAPE_RE.exec(text);
  if (!shaped) return {};
  return addDivisionAndJudge({ "Case Number": shaped[1] + shaped[2] + shaped[3] + shaped[4] }, text);
}
