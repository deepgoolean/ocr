// Port of app/case_caption_extraction.py. US legal filings overwhelmingly
// share this caption structure:
//   <party name(s)>
//   Plaintiff,
//   v.
//   <party name(s)>
//   Defendant(s).
// This is a structural/layout pattern, not natural prose — exactly what a
// general QA/generative model handles poorly. Verified across four
// separate real-document test rounds this session with four different AI
// approaches (extractive QA, extractive QA asked fixed field questions, a
// small generative LLM, and a larger generative LLM (Phi-3-mini, ~3.8B)):
// every one either got the plaintiff wrong/missing, fabricated text, or
// was too slow to be usable (Phi-3-mini took ~7 minutes per document on
// CPU) — while this deterministic parser was correct and near-instant on
// every real filing tested. A parser keyed off these caption markers is
// the right tool for this specific, extremely common structural question.

const PLAINTIFF_LABEL_RE = /^plaintiffs?\.?,?\b/i;
const DEFENDANT_LABEL_RE = /^defendants?\(?s?\)?\.?,?\b/i;
const VS_LABEL_RE = /^v\.?s?\.?,?$/i;

// case\s*no\.?.* / case\s*number.* (not just a bare "...:?" label) so a
// caption line like "CASE No. 2020 CA 001231 NC" — the case number typed
// inline with no colon, verified on a real filing — doesn't get swept into
// the plaintiff name by the backward scan below (it produced "CASE No.
// 2020 CA 001231 NC U.S. BANK TRUST NATIONAL ASSOCIATION..." before this
// fix). The actual case number itself is captured separately by
// caseInfoExtraction.js, so this parser only needs to recognize and skip
// the line, not parse its value.
const NOISE_LABEL_RE =
  /^(general\s+jurisdiction|jurisdiction\s+division|division:?|case\s*no\.?\b.*|case\s*number\b.*|div:?\s*\w*)$/i;

// OCR sometimes misreads the "v." divider itself as unrecognizable garbage
// — verified on a real scanned filing where it came out as "\2" (not "v."
// or "vs." in any recognizable form), which VS_LABEL_RE can't match, so it
// fell through into the defendant name as "\2 Jeannie Quinteros, et al".
// A line with no letters at all and only a handful of characters is never
// real party-name content, whatever OCR turned "v." into, so it's treated
// as noise and skipped rather than trying to enumerate every possible OCR
// misread of a single character.
const NOISE_TOKEN_RE = /^[^A-Za-z]{1,4}$/;

const COURT_HEADER_RE =
  /^(IN THE .*(COURT|CIRCUIT).*|.*JUDICIAL (CIRCUIT|DISTRICT).*|IN AND FOR .*|.*COUNTY,?\s*[A-Z]{2,}\.?$)/i;

// Some PDFs' text extraction puts each word of a fully-justified party
// name on its own line (e.g. "TOWN" / "VILLAS" / "AT" / "MOON" / "LAKE" /
// "HOMEOWNERS ASSOCIATION, INC.," as six separate lines for one plaintiff
// name) — verified against a real filing where a cap of 5 silently dropped
// the first word ("TOWN"). Raised with headroom for longer corporate/HOA
// names in this same layout.
const MAX_PARTY_LINES = 12;

function cleanParty(lines) {
  return lines.join(" ").replace(/\s+/g, " ").trim().replace(/^[ ,;]+|[ ,;]+$/g, "");
}

function findLabel(lines, pattern, start = 0) {
  for (let i = start; i < lines.length; i++) {
    if (pattern.test(lines[i])) return i;
  }
  return -1;
}

export function extractParties(text) {
  const lines = text.split("\n").map((ln) => ln.trim());

  const pIdx = findLabel(lines, PLAINTIFF_LABEL_RE);
  if (pIdx === -1) return {};

  const vIdx = findLabel(lines, VS_LABEL_RE, pIdx + 1);
  const dIdx = findLabel(lines, DEFENDANT_LABEL_RE, vIdx !== -1 ? vIdx + 1 : pIdx + 1);

  // Plaintiff name: scan backward from the "Plaintiff," marker, collecting
  // real content lines and skipping administrative labels, stopping at the
  // jurisdiction header or a blank line once something's been found.
  const plaintiffLines = [];
  let i = pIdx - 1;
  while (i >= 0 && plaintiffLines.length < MAX_PARTY_LINES) {
    const line = lines[i];
    if (!line) {
      if (plaintiffLines.length) break;
      i -= 1;
      continue;
    }
    if (COURT_HEADER_RE.test(line)) break;
    if (NOISE_LABEL_RE.test(line) || PLAINTIFF_LABEL_RE.test(line) || NOISE_TOKEN_RE.test(line)) {
      i -= 1;
      continue;
    }
    plaintiffLines.unshift(line);
    i -= 1;
  }
  const plaintiff = cleanParty(plaintiffLines);

  // Defendant name(s): everything between the "v."/"vs." marker (or the
  // plaintiff marker, if no "v." was found) and the "Defendant(s)" marker.
  let defendant = "";
  if (dIdx !== -1) {
    const start = vIdx !== -1 ? vIdx + 1 : pIdx + 1;
    const defendantLines = [];
    for (let j = start; j < dIdx; j++) {
      if (lines[j] && !NOISE_LABEL_RE.test(lines[j]) && !VS_LABEL_RE.test(lines[j]) && !NOISE_TOKEN_RE.test(lines[j])) {
        defendantLines.push(lines[j]);
      }
    }
    defendant = cleanParty(defendantLines);
  }

  const result = {};
  if (plaintiff) result.Plaintiff = plaintiff;
  if (defendant) result.Defendant = defendant;
  return result;
}
