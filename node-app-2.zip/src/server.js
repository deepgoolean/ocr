import express from "express";
import multer from "multer";
import { config } from "./config.js";
import { extractPages } from "./pipeline.js";
import { startPool, stopPool } from "./ocrPool.js";
import { extractParties } from "./caseCaptionExtraction.js";
import { extractCaseInfo } from "./caseInfoExtraction.js";
import { extractKeyValues } from "./keyValueExtraction.js";
import { answerQuestions, warmUp as warmUpQa } from "./qaExtraction.js";

const PDF_MAGIC = Buffer.from("%PDF");

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: config.maxUploadMb * 1024 * 1024 },
});

async function analyzeDocument(filename, content, questions) {
  const base = await extractPages(filename, content);

  const analysisStart = process.hrtime.bigint();
  const parties = extractParties(base.full_text);
  const caseInfo = extractCaseInfo(base.full_text);
  // Case-number captions with no colon after "CASE NO" (e.g. Broward's
  // "CASE NO. CACE16006184 DIVISION: 11 JUDGE: ...") can trick the generic
  // "Label: Value" regex into matching the first colon it finds anywhere
  // later on that same line, producing a garbled label like "CASE NO.
  // CACE16006184 DIVISION" — verified on a real filing. caseInfoExtraction.js
  // already parses this line correctly, so generic key-value matches that
  // start with "case no"/"case number" are dropped as redundant/wrong
  // duplicates rather than left in fields alongside the correct one.
  const CASE_NO_KEY_RE = /^case\s*(no\.?|number)\b/i;
  const fields = [
    ...Object.entries(parties).map(([key, value]) => ({ key, value })),
    ...Object.entries(caseInfo).map(([key, value]) => ({ key, value })),
    ...extractKeyValues(base.full_text).filter((f) => !CASE_NO_KEY_RE.test(f.key)),
  ];
  const answers = await answerQuestions(base.full_text, questions, { fields });
  const analysisSeconds = Number(process.hrtime.bigint() - analysisStart) / 1e9;

  return {
    ...base,
    fields,
    answers,
    processing_time_seconds: Number((base.processing_time_seconds + analysisSeconds).toFixed(3)),
  };
}

const app = express();

app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

app.post("/extract-text-simple", upload.array("files"), async (req, res) => {
  const files = req.files || [];
  if (files.length === 0) {
    return res.status(400).json({ detail: "No files uploaded" });
  }

  const results = [];
  const errors = [];

  await Promise.all(
    files.map(async (file) => {
      if (!file.buffer.subarray(0, 4).equals(PDF_MAGIC)) {
        errors.push({ filename: file.originalname, error: "Not a valid PDF file" });
        return;
      }
      try {
        results.push(await extractPages(file.originalname, file.buffer));
      } catch (exc) {
        errors.push({ filename: file.originalname, error: String(exc.message || exc) });
      }
    })
  );

  res.json({ results, errors });
});

// Text extraction + hybrid analysis: fields (plaintiff, defendant, case
// no., division, judge, addresses, etc.) come from deterministic parsers
// (caseCaptionExtraction.js, caseInfoExtraction.js, keyValueExtraction.js),
// and free-form question answering (qaExtraction.js) uses the QA model,
// routing plaintiff/defendant/case-number/address questions to the
// already-parsed field values instead of the model. Settled on this after
// testing four different AI-only approaches against real documents this
// session (extractive QA alone, extractive QA asked fixed field questions,
// a small generative LLM, and a larger one — Phi-3-mini): all four were
// less accurate than these parsers, and Phi-3-mini in particular took
// ~7 minutes per document on CPU, which is the deciding factor as much as
// accuracy — this hybrid is both correct and near-instant.
app.post("/extract", upload.array("files"), async (req, res) => {
  const files = req.files || [];
  if (files.length === 0) {
    return res.status(400).json({ detail: "No files uploaded" });
  }

  const questions = [].concat(req.body?.questions || []).filter(Boolean);

  const results = [];
  const errors = [];

  await Promise.all(
    files.map(async (file) => {
      if (!file.buffer.subarray(0, 4).equals(PDF_MAGIC)) {
        errors.push({ filename: file.originalname, error: "Not a valid PDF file" });
        return;
      }
      try {
        results.push(await analyzeDocument(file.originalname, file.buffer, questions));
      } catch (exc) {
        errors.push({ filename: file.originalname, error: String(exc.message || exc) });
      }
    })
  );

  res.json({ results, errors });
});

// multer's fileSize limit surfaces as this error code rather than throwing
// inside the route handler above.
app.use((err, req, res, next) => {
  if (err && err.code === "LIMIT_FILE_SIZE") {
    return res.status(400).json({ detail: `File exceeds ${config.maxUploadMb}MB limit` });
  }
  next(err);
});

async function main() {
  await Promise.all([startPool(), warmUpQa()]);
  const server = app.listen(config.port, "0.0.0.0", () => {
    console.log(`Node OCR API listening on port ${config.port}`);
  });

  const shutdown = async () => {
    server.close();
    await stopPool();
    process.exit(0);
  };
  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
}

main();
